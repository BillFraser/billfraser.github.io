/*
	@Author William Fraser
	Covered by GNU AGPL: (http://BillFraser.github.io/LICENSE.md)

*/

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.util.Set;
import java.util.TreeSet;
import java.util.Random;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.util.zip.*;
import java.util.Date;
import java.text.SimpleDateFormat;

public class MazeGenerator {

	static final int[] X = {0,1,2,3,4,4,4,4,4,3,2,1,0,0,0,0};
	static final int[] Y = {0,0,0,0,0,1,2,3,4,4,4,4,4,3,2,1};
	static final int[] ROT = {2,3,3,3,3,0,0,0,0,1,1,1,1,2,2,2};

	static final int[] SHAPE_SPIRAL = {26,5,5,5,9,5,5,9,26,5,5,5,9,5,5,9,10,10,12,6,10,9,3,10,10};
	static final int[] SHAPE_SLALOM = {26,5,5,5,9,12,9,12,26,5,5,5,9,12,9,12,10,10,10,10,10,10,10,10,10,10};
	static final int[] SHAPE_LINE = {0,0,0,0,0,0,26,0,0,0,0,0,0,0,26,0,0,0,0,10,10,10,0,0,0};

	static boolean USE_GROOVE = true;
	static boolean CHECKERBOARD = false;

	static final double HORIZ_VERT_BIAS = 0.85;

	static final int MODEL_BASE_HEIGHT = USE_GROOVE ? 5000 : 2000;
	static final int MODEL_RAIL_HEIGHT = USE_GROOVE ? -3000 : 3000;
	static final int MODEL_COMBINED_HEIGHT = MODEL_BASE_HEIGHT+MODEL_RAIL_HEIGHT;

	static final int MODEL_GRID_SIZE = 5000;

	static final int MODEL_LINE_WIDTH = 800;

	static final int MODEL_RAIL_WIDTH = USE_GROOVE ? (MODEL_GRID_SIZE-MODEL_LINE_WIDTH) : MODEL_LINE_WIDTH;
	static final int MODEL_RAIL_START = (MODEL_GRID_SIZE-MODEL_RAIL_WIDTH)/2;
	static final int MODEL_RAIL_END = (MODEL_GRID_SIZE+MODEL_RAIL_WIDTH)/2;

	static final int MODEL_NECK_WIDTH = 2000;		// was 1600	+200 per 100 	1400 for V-6	2000 for V-8
	static final int MODEL_NECK_LENGTH = 1400;		// was 800	-100 per 100 	700 for V-6	1200 for V-8
	static final int MODEL_HEAD_WIDTH = 3600;		// was 2000	+200 per 100 	2400 for V-6	3400 for V-8
	static final int MODEL_HEAD_LENGTH = 2000;		// was 2000	+200 per 100 	1300 for V-6	1800 for V-8

	static final int MODEL_BUMP_SLACK = 500;		// was 200			300 for V-6	400 for V-8

	static final int MODEL_NECK_START = (MODEL_GRID_SIZE-MODEL_NECK_WIDTH)/2;
	static final int MODEL_NECK_END = (MODEL_GRID_SIZE+MODEL_NECK_WIDTH)/2;
	static final int MODEL_HEAD_START = (MODEL_GRID_SIZE-MODEL_HEAD_WIDTH)/2;
	static final int MODEL_HEAD_END = (MODEL_GRID_SIZE+MODEL_HEAD_WIDTH)/2;

	static final Long fakeTime = null;			// Used for debugging, so the zip files match

	boolean groove = true;

	int subs;
	int half;
	int corridor;
	int margin;
	int size;

	int leftMask;
	int rightMask;
	int mid3Mask;
	int mid1Mask;

	boolean[][][] tunnels;
	boolean[][] nsWalls;
	boolean[][] ewWalls;
	int[][] distance;
	boolean[][] solution;
	int[][] regions;

	Set<Integer> freeze=new TreeSet<>();

	int region;
	int merges;
	int remaining;

	Set<Integer> taken = new TreeSet<>();

	long seed;
	Random random;
	boolean splitMode;
	boolean hard;
	int[] shape;
	boolean threeD;

	java.util.Map<java.util.List<Integer>,Integer> vertexMap = new java.util.HashMap<>();
	java.util.List<java.util.List<Integer>> vertices = new java.util.ArrayList<>();
	java.util.List<java.util.List<Integer>> triangles = new java.util.ArrayList<>();

	MazeGenerator() {
		this(10, 0, false, false, "line", true);
	}

	MazeGenerator(int subs, long seed, boolean splitMode, boolean hard, String shapeName, boolean threeD) {
		if(seed == 0)
			seed = System.nanoTime();
		this.seed = seed;
		random = new Random(seed);
		this.splitMode = splitMode;
		this.hard = hard;
		setShape(shapeName);
		this.threeD = threeD;

		this.subs = subs;
		half = subs/2;
		corridor = 20;
		margin = subs;
		size = subs*corridor + 2*margin;

		leftMask = (1<<subs) - (2<<half);
		rightMask = (1<<(half-1)) - 1;
		mid3Mask = (3<<(half-1));
		mid1Mask = (1<<(half-1));

		tunnels = new boolean[5][5][4];
		nsWalls = new boolean[5*subs][5*subs+1];
		ewWalls = new boolean[5*subs+1][5*subs];
		distance = new int[5*subs][5*subs];
		solution = new boolean[5*subs][5*subs];
		regions = new int[5*subs][5*subs];

		region=1;
		merges=0;
		remaining=(subs*5)*(subs*5)-1;

		for(int i=0;i<subs*5;i++) {
			for(int j=0;j<=subs*5;j++) {
				nsWalls[i][j]=true;
				ewWalls[j][i]=true;
			}
		}
	}

	void setShape(String shapeName) {
		if("spiral".equalsIgnoreCase(shapeName))
			shape = SHAPE_SPIRAL;
		else if("slalom".equalsIgnoreCase(shapeName))
			shape = SHAPE_SLALOM;
		else if("line".equalsIgnoreCase(shapeName))
			shape = SHAPE_LINE;
		else
			throw new RuntimeException("Unknown shape: "+shapeName);
	}

	void setBorder(int[] borders) {
		int[] lookup = new int[16];
		int[] lookup2 = new int[16];
		int link=0;
		int link2=0;
		for(int i=0;i<16;i++) {
			lookup[link]=i;
			link = borders[link];
			lookup2[link2]=i;
			link2 = borders[link2]^1;
		}
		if(link!=0)
			throw new RuntimeException();
		if(link2!=0)
			throw new RuntimeException();
		for(int i=0;i<16;i++) {
			int x = X[i];
			int y = Y[i];
			int rot = ROT[i];
			int s = shape[lookup[link]];
			if((s&16)==16) {
				createExit(x,y,rot);
			}
			for(int k=0;k<4;k++) {
				if((s&(1<<k))!=0)
					tunnels[x][y][(k+rot)%4]=true;
			}
			link = borders[link]^1;
		}
		for(int i=0;i<16;i+=2) {
			int value = getValue();
			link=lookup2[i];
			setBoundary(X[link],Y[link],ROT[link],value);
			link=lookup2[i+1];
			setBoundary(X[link],Y[link],ROT[link],value);
		}
	}

	void createExit(int x, int y, int rot) {
		switch(rot) {
			case 0:
				ewWalls[x*subs+subs][y*subs+half]=false;
				ewWalls[x*subs+subs][y*subs+half-1]=false;
				break;
			case 1:
				nsWalls[x*subs+half][y*subs+subs]=false;
				nsWalls[x*subs+half-1][y*subs+subs]=false;
				break;
			case 2:
				ewWalls[x*subs][y*subs+half]=false;
				ewWalls[x*subs][y*subs+half-1]=false;
				break;
			case 3:
				nsWalls[x*subs+half][y*subs]=false;
				nsWalls[x*subs+half-1][y*subs]=false;
				break;
		}
	}

	void setLookups(int[] lookup, int[] dualLookup) {
		int value=0;
		for(int i=0;i<24;i++) {
			if((i%2)==0)
				value = getValue();
			int link = dualLookup[i];
			int x = ((link/4)%3)+1;
			int y = ((link/12)%3)+1;
			int rot = link%4;
			//System.out.println(i+" "+x+" "+y+" "+rot);

			int rot2 = (rot - (lookup[i]%4) + 4)%4;
			int s = shape[16+lookup[i]/4];
			for(int k=0;k<4;k++) {
				if((s&(1<<k))!=0)
					tunnels[x][y][(k+rot2)%4]=true;
			}
			if((x==2 && y==3 && rot==0) || (x==1 && y==2 && rot==1) || (x==2 && y==1 && rot==2) || (x==3 && y==2 && rot==3)) {
				int link3=lookup[i^1];
				int s2 = shape[16+link3/4];
				//System.out.println(i+ " Special case: "+link3+" "+s2+" "+x+" "+y+" "+rot);
				if((s2 & (1<<(link3%4)))!=0) {
					//System.out.println("Activating: "+((2+rot)%4));
					tunnels[2][2][(2+rot)%4]=true;
				}
			}
			setBoundary(x,y,rot,value);
		}
		//applyTunnels();
		//printMaze(11,false);
	}

	int getValue() {
		for(int i=0;i<200000;i++) {
			int test = (int)(random.nextDouble()*(1<<subs));
			if(i>=100000)
				test=i-100000;
			test = (test | mid3Mask) - (mid1Mask);
			if((test & leftMask)==leftMask)
				continue;
			if((test & rightMask)==rightMask)
				continue;
			if(!taken.contains(test)) {
				taken.add(test);
				return test;
			}
		}
		throw new RuntimeException();
	}

	void setBoundary(int x, int y, int side, int value) {
		for(int k=0;k<subs;k++) {
			if((value & (1<<k))==0) {
				switch(side) {
					case 0:
						clearNSWall(x*subs+k,y*subs);
						break;
					case 1:
						clearEWWall(x*subs+subs,y*subs+k);
						break;
					case 2:
						clearNSWall(x*subs+subs-1-k,y*subs+subs);
						break;
					case 3:
						clearEWWall(x*subs,y*subs+subs-1-k);
						break;
				}
			}
		}
	}

	void clearNSWall(int x, int y) {
		nsWalls[x][y] = false;
		remaining--;
		if(regions[x][y]==0) {
			if(regions[x][y-1]==0) {
				regions[x][y]=region;
				regions[x][y-1]=region;
				region++;
			} else {
				regions[x][y]=regions[x][y-1];
			}
		} else {
			if(regions[x][y-1]==0) {
				regions[x][y-1]=regions[x][y];
			} else if(regions[x][y-1] == regions[x][y]) {
				remaining++;
			} else {
				mergeRegions(regions[x][y-1], regions[x][y]);
			}
		}
	}

	void clearEWWall(int x, int y) {
		ewWalls[x][y] = false;
		remaining--;
		if(regions[x][y]==0) {
			if(regions[x-1][y]==0) {
				regions[x][y]=region;
				regions[x-1][y]=region;
				region++;
			} else {
				regions[x][y]=regions[x-1][y];
			}
		} else {
			if(regions[x-1][y]==0) {
				regions[x-1][y]=regions[x][y];
			} else if(regions[x-1][y] == regions[x][y]) {
				remaining++;
			} else {
				mergeRegions(regions[x-1][y], regions[x][y]);
			}
		}
	}

	void mergeRegions(int r1, int r2) {
		merges++;
		for(int i=0;i<regions.length;i++)
			for(int j=0;j<regions[0].length;j++)
				if(regions[i][j]==r1)
					regions[i][j]=r2;
	}

	void generateMaze() {
		applyTunnels();
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				int r = regions[i*subs+half][j*subs+half];
				if(r==0)
					continue;
				freeze.add(r);
			}
		}
		//System.out.println(freeze);
		if(freeze.size()==1) {
			System.out.println("Maze has two trivial solutions!");
			return;
			//throw new RuntimeException("Maze has two trivial solutions!");
		}
		if(hard)
			remaining-=freeze.size();
		long count=0;
		while(remaining>0) {
			int u = random.nextInt(5)*subs + random.nextInt(subs-1)+1;
			int v = random.nextInt(5)*subs + random.nextInt(subs);
			boolean goal = CHECKERBOARD ? ((((u/subs)+(v/subs))%2)==0) : true;
			if(goal == (random.nextDouble() > HORIZ_VERT_BIAS)) {
				if(hard && (freeze.contains(regions[u][v]) || freeze.contains(regions[u-1][v])))
					continue;
				if(regions[u][v]==0 || regions[u][v] != regions[u-1][v])
					clearEWWall(u,v);
				else
					continue;
			} else {
				if(hard && (freeze.contains(regions[v][u]) || freeze.contains(regions[v][u-1])))
					continue;
				if(regions[v][u]==0 || regions[v][u] != regions[v][u-1])
					clearNSWall(v,u);
				else
					continue;
			}
		}
		if(hard) {
			for(int i=0;i<5;i++) {
				if(!ewWalls[0][subs*i+half])
					clearNSWall(0,subs*i+half-1);
				if(!ewWalls[5*subs][i*subs+half])
					clearNSWall(5*subs-1,i*subs+half+1);
				if(!nsWalls[i*subs+half][5*subs])
					clearEWWall(i*subs+half-1,5*subs-1);
				if(!nsWalls[i*subs+half][1])
					clearEWWall(i*subs+half+1,0);
			}
		}
	}

	void applyTunnels() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				if(tunnels[i][j][0]) {
					for(int k=1;k<=half;k++) {
						clearNSWall(subs*i+half,subs*j+k);
						clearEWWall(subs*i+half,subs*j+k-1);
						clearNSWall(subs*i+half-1,subs*j+k);
					}
				}
				if(tunnels[i][j][1]) {
					for(int k=subs-1;k>=half;k--) {
						clearEWWall(subs*i+k,subs*j+half-1);
						clearNSWall(subs*i+k,subs*j+half);
						clearEWWall(subs*i+k,subs*j+half);
					}
				}
				if(tunnels[i][j][2]) {
					for(int k=subs-1;k>=half;k--) {
						clearNSWall(subs*i+half,subs*j+k);
						clearEWWall(subs*i+half,subs*j+k);
						clearNSWall(subs*i+half-1,subs*j+k);
					}
				}
				if(tunnels[i][j][3]) {
					for(int k=1;k<=half;k++) {
						clearEWWall(subs*i+k,subs*j+half-1);
						clearNSWall(subs*i+k-1,subs*j+half);
						clearEWWall(subs*i+k,subs*j+half);
					}
				}
			}
		}	
	}

	void printMaze(int x, boolean withSolution) {
		String seedString = Long.toHexString(seed).toUpperCase();
		if(threeD) {
			for(int j=0;j<5;j++) {
				for(int i=0;i<5;i++) {
					print3D(i,j,subs+"."+x+"."+seedString+"."+i+j+".3mf");
				}
			}
		}
		if(splitMode) {
			printMaze(0,3,subs+"."+x+"."+seedString+"A.png");
			printMaze(3,5,subs+"."+x+"."+seedString+"B.png");
		} else {
			printMaze(0,5,subs+"."+x+"."+seedString+".png");
		}
		
		if(withSolution) {
			if(!solve())
				throw new RuntimeException("Can't solve!");
			printMaze(0,5,subs+"."+x+"."+seedString+".answer.png");
		}
	} 

	boolean solve() {
		for(int i=0;i<5;i++) {
			if(!ewWalls[0][subs*i+half]) {
				distance[0][subs*i+half]=1;
				distance[0][subs*i+half-1]=1;
				break;
			}
			if(!ewWalls[5*subs][i*subs+half]) {
				distance[5*subs-1][i*subs+half]=1;
				distance[5*subs-1][i*subs+half-1]=1;
				break;
			}
			if(!nsWalls[i*subs+half][5*subs]) {
				distance[i*subs+half][5*subs-1]=1;
				distance[i*subs+half-1][5*subs-1]=1;
				break;
			}
			if(!nsWalls[i*subs+half][0]) {
				distance[i*subs+half][0]=1;
				distance[i*subs+half-1][0]=1;
				break;
			}
		}
		for(int t=1;t<25*subs*subs;t++) {
			boolean found=false;
			for(int x=0;x<5*subs;x++) {
				for(int y=0;y<5*subs;y++) {
					if(distance[x][y]==t) {
						if(t>1 && nearExit(x,y))
							return updateSolution(x,y);
						found=true;
						if(x>0 && !ewWalls[x][y] && distance[x-1][y]==0)
							distance[x-1][y]=t+1;
						if(x<5*subs-1 && !ewWalls[x+1][y] && distance[x+1][y]==0)
							distance[x+1][y]=t+1;
						if(y>0 && !nsWalls[x][y] && distance[x][y-1]==0)
							distance[x][y-1]=t+1;
						if(y<5*subs-1 && !nsWalls[x][y+1] && distance[x][y+1]==0)
							distance[x][y+1]=t+1;
					}
				}
			}
			if(!found)
				return false;
		}
		return false;
	}

	boolean updateSolution(int x, int y) {
		for(int t=distance[x][y];t>0;t--) {
			solution[x][y]=true;
			if(t==1)
				return true;
			if(x>0 && !ewWalls[x][y] && distance[x-1][y]==t-1)
				x--;
			else if(x<5*subs-1 && !ewWalls[x+1][y] && distance[x+1][y]==t-1)
				x++;
			else if(y>0 && !nsWalls[x][y] && distance[x][y-1]==t-1)
				y--;
			else if(y<5*subs-1 && !nsWalls[x][y+1] && distance[x][y+1]==t-1)
				y++;
		}
		return false;
	}

	boolean nearExit(int x, int y) {
		if(x==0 && !ewWalls[x][y])
			return true;	
		if(y==0 && !nsWalls[x][y])
			return true;	
		if(x==5*subs-1 && !ewWalls[x+1][y])
			return true;	
		if(y==5*subs-1 && !nsWalls[x][y+1])
			return true;
		return false;
	}

	void print3D(int x, int y, String fileName) {
		try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(fileName),10240))) {
			printRels(zos);
			printContentTypes(zos);
			printModel(zos,x,y);
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
	}

	void setupEntry(ZipOutputStream zos, String fileName) throws IOException {
		ZipEntry ze = new ZipEntry(fileName);
		if(fakeTime!=null)
			ze.setTime(fakeTime);
		zos.putNextEntry(ze);
	}

	void printContent(ZipOutputStream zos, String text) throws IOException {
		zos.write(text.getBytes());
//System.out.print(text);
	}

	void printRels(ZipOutputStream zos) throws IOException {
		setupEntry(zos,"_rels/.rels");
		try (InputStream is = getInputStream(".rels")) {
			is.transferTo(zos);
		}
		zos.closeEntry();
	}

	void printContentTypes(ZipOutputStream zos) throws IOException {
		setupEntry(zos,"[Content_Types].xml");
		try (InputStream is = getInputStream("[Content_Types].xml")) {
			is.transferTo(zos);
		}
		zos.closeEntry();
	}

	InputStream getInputStream(String name) throws IOException {
		if(new File(name).exists())
			return new FileInputStream(name);
		return this.getClass().getClassLoader().getResourceAsStream(name);
	}

	void printModel(ZipOutputStream zos, int x, int y) throws IOException {
		calc3DModel(x,y);

		Date date = new Date();
		String year = new SimpleDateFormat("yyyy").format(date);
		String day = new SimpleDateFormat("yyyy-MM-dd").format(date);
		if(fakeTime != null) {
			year="2000";
			day="2000-01-01";
		}
		setupEntry(zos,"3D/3dmodel.model");
		printContent(zos,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		printContent(zos,"<model unit=\"micron\" xml:lang=\"en-US\" xmlns:m=\"http://schemas.microsoft.com/3dmanufacturing/material/2015/02\" xmlns=\"http://schemas.microsoft.com/3dmanufacturing/core/2015/02\">\n");
		printContent(zos,"  <metadata name=\"CreationDate\">"+day+"</metadata>\n");
		printContent(zos,"  <metadata name=\"Description\">Puzzle Piece</metadata>\n");
		printContent(zos,"  <metadata name=\"Copyright\">Copyright (c) "+year+" William E Fraser.  Covered by GNU AGPL: (http://BillFraser.github.io/LICENSE.md) </metadata>\n");
		printContent(zos,"  <resources>\n");
		printContent(zos,"    <m:colorgroup id=\"1\">\n");
		printContent(zos,"      <m:color color=\"#FFFFFFFF\" />\n");
		printContent(zos,"      <m:color color=\"#000000FF\" />\n");
		printContent(zos,"    </m:colorgroup>\n");
		printContent(zos,"    <object id=\""+(1000+10*x+y)+"\" name=\"Piece "+x+", "+y+"\" type=\"model\" pid=\"1\" pindex=\"0\">\n");
		printContent(zos,"      <mesh>\n");
		print3DVertices(zos);
		print3DTriangles(zos);
		printContent(zos,"      </mesh>\n");
		printContent(zos,"    </object>\n");
		printContent(zos,"  </resources>\n");
		printContent(zos,"  <build>\n");
		printContent(zos,"    <item objectid=\""+(1000+10*x+y)+"\" />\n");
		printContent(zos,"  </build>\n");
		printContent(zos,"</model>\n");
		zos.closeEntry();
	}

	void calc3DModel(int x, int y) {
		vertices.clear();
		vertexMap.clear();
		triangles.clear();

		calcSWCornerBlock();
		calcNWCornerBlock();
		calcNECornerBlock();
		calcSECornerBlock();

		for(int j=0;j<subs;j++) {
			calcNEdgeBlock(j,x,y);
			calcSEdgeBlock(j,x,y);
			calcEEdgeBlock(j,x,y);
			calcWEdgeBlock(j,x,y);
			for(int i=0;i<subs;i++) {
				calcInteriorBlock(i,j,x,y);
			}
		}
		calcBottomRectangle(MODEL_GRID_SIZE*2,MODEL_GRID_SIZE*2,0,MODEL_GRID_SIZE*subs,MODEL_GRID_SIZE*subs,0);
	}

	void calcSWCornerBlock() {
//System.out.println("SWCornerBlock");
		int bx=MODEL_GRID_SIZE;
		int by=MODEL_GRID_SIZE;
		calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcTopRectangle(bx,bx,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcLeftRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
		calcFrontRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
	}

	void calcNWCornerBlock() {
//System.out.println("NWCornerBlock");
		int bx=MODEL_GRID_SIZE;
		int by=MODEL_GRID_SIZE*(subs+2);
		calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcLeftRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
		calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
	}

	void calcNECornerBlock() {
//System.out.println("NECornerBlock");
		int bx=MODEL_GRID_SIZE*(subs+2);
		int by=MODEL_GRID_SIZE*(subs+2);
		calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
		calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
	}

	void calcSECornerBlock() {
//System.out.println("SECornerBlock");
		int bx=MODEL_GRID_SIZE*(subs+2);
		int by=MODEL_GRID_SIZE;
		calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
		calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
		calcFrontRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
	}

	void calcNEdgeBlock(int i, int x, int y) {
		int bx=MODEL_GRID_SIZE*(i+2);
		int by=MODEL_GRID_SIZE*(subs+2);
		int wallX = x*subs+i;
		int wallY = (4-y)*subs;
		if(wallY==0) {
			if(nearExit(wallX,wallY)) {
				if(i==half) {
//System.out.println("NEdgeBlock nearExit i==half");
					calcTopRectangle(bx,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_END,MODEL_GRID_SIZE,1);
					calcBackRectangle(bx,by+MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
					calcRightRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
				} else {
//System.out.println("NEdgeBlock nearExit i!=half");
					calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
					calcLeftRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_END,MODEL_GRID_SIZE,1);
					calcBackRectangle(bx+MODEL_RAIL_START,by+MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
				}
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("NEdgeBlock not nearExit");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			}
		} else if(nsWalls[wallX][wallY]) {
			if(((i+half)&1)==1) {
//System.out.println("NEdgeBlock bump");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcTopRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0);
				calcTopRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE,0,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0);
				calcBottomRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,0);

				calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH-MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_HEAD_END-MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by+MODEL_GRID_SIZE,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("NEdgeBlock dent");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0);
				calcTopRectangle(bx,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcTopRectangle(bx+MODEL_HEAD_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcTopRectangle(bx,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcTopRectangle(bx+MODEL_NECK_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,MODEL_NECK_START,MODEL_NECK_LENGTH,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0);
				calcBottomRectangle(bx,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcBottomRectangle(bx+MODEL_HEAD_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcBottomRectangle(bx,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcBottomRectangle(bx+MODEL_NECK_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,MODEL_NECK_START,MODEL_NECK_LENGTH,0);

				calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_START,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_HEAD_START,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_HEAD_START,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_HEAD_START,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0,MODEL_HEAD_WIDTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_HEAD_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_NECK_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_NECK_END,by+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_NECK_END,by+MODEL_GRID_SIZE,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
			}
		} else {
			// create plain box with raised rail
//System.out.println("NEdgeBlock plain");
			calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
			calcLeftRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_WIDTH,MODEL_GRID_SIZE,1);
			calcRightRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
//calcFrontRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
			calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
			calcBackRectangle(bx,by+MODEL_GRID_SIZE,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
			calcBackRectangle(bx+MODEL_RAIL_START,by+MODEL_GRID_SIZE,0,MODEL_RAIL_WIDTH,MODEL_COMBINED_HEIGHT,0);
			calcBackRectangle(bx+MODEL_RAIL_END,by+MODEL_GRID_SIZE,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
		}
	}

	void calcSEdgeBlock(int i, int x, int y) {
		int bx=MODEL_GRID_SIZE*(i+2);
		int by=MODEL_GRID_SIZE;
		int wallX = x*subs+i;
		int wallY = (4-y)*subs+subs-1;
		if(wallY==5*subs-1) {
			if(nearExit(wallX,wallY)) {
				if(i==half) {
//System.out.println("SEdgeBlock nearExit i==half");
					calcTopRectangle(bx,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_END,MODEL_GRID_SIZE,1);
					calcFrontRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
					calcRightRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
				} else {
//System.out.println("SEdgeBlock nearExit i!=half");
					calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
					calcLeftRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_END,MODEL_GRID_SIZE,1);
					calcFrontRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
				}
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcFrontRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("SEdgeBlock not nearExit");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcFrontRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			}
		} else if(nsWalls[wallX][wallY+1]) {
			if(((i+half)&1)==0) {
//System.out.println("SEdgeBlock bump");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcTopRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0);
				calcTopRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,0,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,0);
				calcBottomRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,0);

				calcFrontRectangle(bx,by,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_NECK_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_HEAD_START+MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_HEAD_END-MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_NECK_END-MODEL_BUMP_SLACK,by,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("SEdgeBlock dent");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcTopRectangle(bx+MODEL_NECK_END,by,MODEL_BASE_HEIGHT,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcTopRectangle(bx,by+MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcTopRectangle(bx+MODEL_HEAD_END,by+MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcTopRectangle(bx,by+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0);

				calcBottomRectangle(bx,by,0,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcBottomRectangle(bx+MODEL_NECK_END,by,0,MODEL_NECK_START,MODEL_NECK_LENGTH,0);
				calcBottomRectangle(bx,by+MODEL_NECK_LENGTH,0,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcBottomRectangle(bx+MODEL_HEAD_END,by+MODEL_NECK_LENGTH,0,MODEL_HEAD_START,MODEL_HEAD_LENGTH,0);
				calcBottomRectangle(bx,by+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,0);

				calcFrontRectangle(bx,by,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_START,by,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_HEAD_START,by+MODEL_NECK_LENGTH,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_HEAD_START,by+MODEL_NECK_LENGTH,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_HEAD_START,by+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,0,MODEL_HEAD_WIDTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_HEAD_END,by+MODEL_NECK_LENGTH,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_NECK_END,by+MODEL_NECK_LENGTH,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_NECK_END,by,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_NECK_END,by,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
			}
		} else {
//System.out.println("SEdgeBlock plain");
			// create plain box with raised rail
			calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
			calcLeftRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_WIDTH,MODEL_GRID_SIZE,1);
			calcRightRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
//calcBackRectangle(bx+MODEL_RAIL_START,by+MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_GRID_SIZE,0);
			calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
			calcFrontRectangle(bx,by,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
			calcFrontRectangle(bx+MODEL_RAIL_START,by,0,MODEL_RAIL_WIDTH,MODEL_COMBINED_HEIGHT,0);
			calcFrontRectangle(bx+MODEL_RAIL_END,by,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
		}
	}

	void calcEEdgeBlock(int j, int x, int y) {
		int bx=MODEL_GRID_SIZE*(subs+2);
		int by=MODEL_GRID_SIZE*(j+2);
		int wallX = x*subs+subs-1;
		int wallY = (4-y)*subs+(subs-1-j);
		if(wallX==5*subs-1) {
			if(nearExit(wallX,wallY)) {
				if(j==half) {
//System.out.println("EEdgeBlock nearExit j==half");
					calcTopRectangle(bx,by,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_END,1);
					calcRightRectangle(bx+MODEL_GRID_SIZE,by,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
					calcBackRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
				} else {
//System.out.println("EEdgeBlock nearExit j!=half");
					calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
					calcFrontRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_END,1);
					calcRightRectangle(bx+MODEL_GRID_SIZE,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
				}
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("EEdgeBlock not nearExit");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			}
		} else if(ewWalls[wallX+1][wallY]) {
			if(((j+half)&1)==0) {
//System.out.println("EEdgeBlock bump");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_START+MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,0);

				calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_START+MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH-MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_END-MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_GRID_SIZE+MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("EEdgeBlock dent");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_GRID_SIZE,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by+MODEL_HEAD_END,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcTopRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_NECK_END,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH,MODEL_NECK_START,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by,0,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by+MODEL_HEAD_END,0,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by,0,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcBottomRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_NECK_END,0,MODEL_NECK_LENGTH,MODEL_NECK_START,0);

				calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_NECK_START,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_HEAD_START,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by+MODEL_HEAD_START,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by+MODEL_HEAD_START,0,MODEL_HEAD_WIDTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,by+MODEL_HEAD_END,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_NECK_END,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_GRID_SIZE-MODEL_NECK_LENGTH,by+MODEL_NECK_END,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_GRID_SIZE,by+MODEL_NECK_END,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
			}
		} else {
			// create plain box with raised rail
//System.out.println("EEdgeBlock plain");
			calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
			calcFrontRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_WIDTH,1);
			calcBackRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
			calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
			calcRightRectangle(bx+MODEL_GRID_SIZE,by,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
			calcRightRectangle(bx+MODEL_GRID_SIZE,by+MODEL_RAIL_START,0,MODEL_RAIL_WIDTH,MODEL_COMBINED_HEIGHT,0);
			calcRightRectangle(bx+MODEL_GRID_SIZE,by+MODEL_RAIL_END,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
		}
	}

	void calcWEdgeBlock(int j, int x, int y) {
		int bx=MODEL_GRID_SIZE;
		int by=MODEL_GRID_SIZE*(j+2);
		int wallX = x*subs;
		int wallY = (4-y)*subs+(subs-1-j);
		if(wallX==0) {
			if(nearExit(wallX,wallY)) {
				if(j==half) {
//System.out.println("WEdgeBlock nearExit j==half");
					calcTopRectangle(bx,by,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_END,1);
					calcLeftRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
					calcBackRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
				} else {
//System.out.println("WEdgeBlock nearExit j=="+j);
					calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
					calcFrontRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
					calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_END,1);
					calcLeftRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_END,MODEL_RAIL_HEIGHT,1);
				}
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcLeftRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("WEdgeBlock not nearExit");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcLeftRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_BASE_HEIGHT,0);
			}
		} else if(ewWalls[wallX][wallY]) {
			if(((j+half)&1)==1) {
//System.out.println("WEdgeBlock bump");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcTopRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,0);
				calcTopRectangle(bx-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,0);

				calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
				calcBottomRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_NECK_START+MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_NECK_WIDTH-2*MODEL_BUMP_SLACK,0);
				calcBottomRectangle(bx-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,0);

				calcLeftRectangle(bx,by,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_NECK_START+MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_START+MODEL_BUMP_SLACK,0,MODEL_HEAD_WIDTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH+MODEL_BUMP_SLACK,by+MODEL_HEAD_END-MODEL_BUMP_SLACK,0,MODEL_HEAD_LENGTH-2*MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx-MODEL_NECK_LENGTH-MODEL_BUMP_SLACK,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,MODEL_NECK_LENGTH+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx,by+MODEL_NECK_END-MODEL_BUMP_SLACK,0,MODEL_NECK_START+MODEL_BUMP_SLACK,MODEL_BASE_HEIGHT,0);
			} else {
//System.out.println("WEdgeBlock dent");
				calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcTopRectangle(bx,by+MODEL_NECK_END,MODEL_BASE_HEIGHT,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcTopRectangle(bx+MODEL_NECK_LENGTH,by,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcTopRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_HEAD_END,MODEL_BASE_HEIGHT,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcTopRectangle(bx+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_GRID_SIZE,0);

				calcBottomRectangle(bx,by,0,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcBottomRectangle(bx,by+MODEL_NECK_END,0,MODEL_NECK_LENGTH,MODEL_NECK_START,0);
				calcBottomRectangle(bx+MODEL_NECK_LENGTH,by,0,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcBottomRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_HEAD_END,0,MODEL_HEAD_LENGTH,MODEL_HEAD_START,0);
				calcBottomRectangle(bx+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,by,0,MODEL_GRID_SIZE-MODEL_NECK_LENGTH-MODEL_HEAD_LENGTH,MODEL_GRID_SIZE,0);

				calcLeftRectangle(bx,by,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx,by+MODEL_NECK_START,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_HEAD_START,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcBackRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_HEAD_START,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx+MODEL_NECK_LENGTH+MODEL_HEAD_LENGTH,by+MODEL_HEAD_START,0,MODEL_HEAD_WIDTH,MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_HEAD_END,0,MODEL_HEAD_LENGTH,MODEL_BASE_HEIGHT,0);
				calcRightRectangle(bx+MODEL_NECK_LENGTH,by+MODEL_NECK_END,0,(MODEL_NECK_START-MODEL_HEAD_START),MODEL_BASE_HEIGHT,0);
				calcFrontRectangle(bx,by+MODEL_NECK_END,0,MODEL_NECK_LENGTH,MODEL_BASE_HEIGHT,0);
				calcLeftRectangle(bx,by+MODEL_NECK_END,0,MODEL_NECK_START,MODEL_BASE_HEIGHT,0);
			}
		} else {
////System.out.println("WEdgeBlock plain");
			// create plain box with raised rail
			calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
			calcFrontRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_WIDTH,1);
			calcBackRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_HEIGHT,1);
			calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_GRID_SIZE,MODEL_RAIL_START,0);
			calcBottomRectangle(bx,by,0,MODEL_GRID_SIZE,MODEL_GRID_SIZE,0);
			calcLeftRectangle(bx,by,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
			calcLeftRectangle(bx,by+MODEL_RAIL_START,0,MODEL_RAIL_WIDTH,MODEL_COMBINED_HEIGHT,0);
			calcLeftRectangle(bx,by+MODEL_RAIL_END,0,MODEL_RAIL_START,MODEL_BASE_HEIGHT,0);
		}
	}

	void calcInteriorBlock(int i, int j, int x, int y) {
		int bx=MODEL_GRID_SIZE*(i+2);
		int by=MODEL_GRID_SIZE*(j+2);
		int wallX = x*subs+i;
		int wallY = (4-y)*subs+(subs-1-j);
if(middleOfNowhere(x,y,i,j)) {
//System.out.println(i+" "+j+" middle of nowhere");
}
		if(middleOfNowhere(x,4-y,i,subs-j))
			calcTopRectangle(bx,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,1);
		else
			calcTopRectangle(bx,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,0);

		if(middleOfNowhere(x,4-y,i+1,subs-j))
			calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,1);
		else
			calcTopRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,0);

		if(middleOfNowhere(x,4-y,i,subs-1-j))
			calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,1);
		else
			calcTopRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,0);

		if(middleOfNowhere(x,4-y,i+1,subs-1-j))
			calcTopRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_END,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,1);
		else
			calcTopRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_START,0);

		calcTopRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_WIDTH,1);
		if(nsWalls[wallX][wallY]) {
			calcTopRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_START,0);
			calcBackRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
		} else {
			calcTopRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_END,MODEL_COMBINED_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_START,1);
			if(!middleOfNowhere(x,4-y,i,subs-1-j))
				calcLeftRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
			if(!middleOfNowhere(x,4-y,i+1,subs-1-j))
				calcRightRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
		}
		if(nsWalls[wallX][wallY+1]) {
			calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_START,0);
			calcFrontRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
		} else {
			calcTopRectangle(bx+MODEL_RAIL_START,by,MODEL_COMBINED_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_START,1);
			if(!middleOfNowhere(x,4-y,i,subs-j))
				calcLeftRectangle(bx+MODEL_RAIL_START,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
			if(!middleOfNowhere(x,4-y,i+1,subs-j))
				calcRightRectangle(bx+MODEL_RAIL_END,by,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
		}
		if(ewWalls[wallX+1][wallY]) {
			calcTopRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_WIDTH,0);
			calcRightRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
		} else {
			calcTopRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_WIDTH,1);
			if(!middleOfNowhere(x,4-y,i+1,subs-j))
				calcFrontRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
			if(!middleOfNowhere(x,4-y,i+1,subs-1-j))
				calcBackRectangle(bx+MODEL_RAIL_END,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
		}
		if(ewWalls[wallX][wallY]) {
			calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_WIDTH,0);
			calcLeftRectangle(bx+MODEL_RAIL_START,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_WIDTH,MODEL_RAIL_HEIGHT,1);
		} else {
			calcTopRectangle(bx,by+MODEL_RAIL_START,MODEL_COMBINED_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_WIDTH,1);
			if(!middleOfNowhere(x,4-y,i,subs-j))
				calcFrontRectangle(bx,by+MODEL_RAIL_START,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
			if(!middleOfNowhere(x,4-y,i,subs-1-j))
				calcBackRectangle(bx,by+MODEL_RAIL_END,MODEL_BASE_HEIGHT,MODEL_RAIL_START,MODEL_RAIL_HEIGHT,1);
		}
	}

	void calcTopRectangle(int x1, int y1, int z, int dx, int dy, int color) {
		int v1=getVertex(x1,y1,z);
		int v2=getVertex(x1+dx,y1,z);
		int v3=getVertex(x1+dx,y1+dy,z);
		int v4=getVertex(x1,y1+dy,z);

		calcTriangle(v1,v2,v3,color);
		calcTriangle(v1,v3,v4,color);
	}

	void calcLeftRectangle(int x, int y1, int z1, int dy, int dz, int color) {
		int v1=getVertex(x,y1,z1);
		int v2=getVertex(x,y1,z1+dz);
		int v3=getVertex(x,y1+dy,z1+dz);
		int v4=getVertex(x,y1+dy,z1);

		calcTriangle(v1,v2,v3,color);
		calcTriangle(v1,v3,v4,color);
	}

	void calcBottomRectangle(int x1, int y1, int z, int dx, int dy, int color) {
//System.out.println(x1+",\t"+y1+",\t"+dx+",\t"+dy+",\t"+z);
//new RuntimeException().printStackTrace();
		int v1=getVertex(x1,y1,z);
		int v2=getVertex(x1,y1+dy,z);
		int v3=getVertex(x1+dx,y1+dy,z);
		int v4=getVertex(x1+dx,y1,z);

		calcTriangle(v1,v2,v3,color);
		calcTriangle(v1,v3,v4,color);
	}

	void calcRightRectangle(int x, int y1, int z1, int dy, int dz, int color) {
		int v1=getVertex(x,y1,z1);
		int v2=getVertex(x,y1+dy,z1);
		int v3=getVertex(x,y1+dy,z1+dz);
		int v4=getVertex(x,y1,z1+dz);

		calcTriangle(v1,v4,v3,color);
		calcTriangle(v1,v3,v2,color);
	}

	void calcFrontRectangle(int x1, int y, int z1, int dx, int dz, int color) {
		int v1=getVertex(x1,y,z1);
		int v2=getVertex(x1+dx,y,z1);
		int v3=getVertex(x1+dx,y,z1+dz);
		int v4=getVertex(x1,y,z1+dz);

		calcTriangle(v1,v4,v3,color);
		calcTriangle(v1,v3,v2,color);
	}

	void calcBackRectangle(int x1, int y, int z1, int dx, int dz, int color) {
		int v1=getVertex(x1,y,z1);
		int v2=getVertex(x1,y,z1+dz);
		int v3=getVertex(x1+dx,y,z1+dz);
		int v4=getVertex(x1+dx,y,z1);

		calcTriangle(v1,v4,v3,color);
		calcTriangle(v1,v3,v2,color);
	}

	int getVertex(int x, int y, int z) {
		java.util.List<Integer> v = java.util.Arrays.asList(x,y,z);
		Integer vN = vertexMap.get(v);
		if(vN!=null)
			return vN;
		vN = vertices.size();
		vertexMap.put(v,vN);
		vertices.add(v);
		return vN;
	}

	void calcTriangle(int v1, int v2, int v3, int color) {
		if(color==0) {
			triangles.add(java.util.Arrays.asList(v1, v2, v3));
		} else {
			triangles.add(java.util.Arrays.asList(v1, v2, v3, color));
		}
	}

	void print3DVertices(ZipOutputStream zos) throws IOException {
		printContent(zos,"        <vertices>\n");
		for(java.util.List<Integer> vertex : vertices) {
			printContent(zos,"          <vertex x=\""+vertex.get(0)+"\" y=\""+vertex.get(1)+"\" z=\""+vertex.get(2)+"\" />\n");
		}
		printContent(zos,"        </vertices>\n");
	}

	void print3DTriangles(ZipOutputStream zos) throws IOException {
		printContent(zos,"        <triangles>\n");
		for(java.util.List<Integer> triangle : triangles) {
			if(triangle.size()==3)
				printContent(zos,"          <triangle v1=\""+triangle.get(0)+"\" v2=\""+triangle.get(1)+"\" v3=\""+triangle.get(2)+"\" />\n");
			else
				printContent(zos,"          <triangle v1=\""+triangle.get(0)+"\" v2=\""+triangle.get(1)+"\" v3=\""+triangle.get(2)+"\" pid=\"1\" pindex=\""+triangle.get(3)+"\" />\n");
		}
		printContent(zos,"        </triangles>\n");
	}

	void printMaze(int start, int end, String fileName) {
		BufferedImage bi = new BufferedImage((end-start)*size+1,5*size+1,BufferedImage.TYPE_INT_RGB);
		setRect(bi, 0, 0, bi.getWidth(), bi.getHeight(), 0xFFFFFF);

		for(int i=start;i<end;i++) {
			for(int j=0;j<5;j++) {
				for(int x=0;x<=subs;x++) {
					for(int y=0;y<=subs;y++) {
						if(x!=subs) {
							if(nsWalls[i*subs+x][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x;
								int width = corridor;
								int top=size*j+margin+corridor*y-1;
								int height = 3;
								if((y==0) && (j!=0)) {
									top -= (margin-1);
									height += (margin-1);
								}
								if((y==subs) && (j!=4)) {
									height += (margin-1);
								}
								setRect(bi, left, top, width, height, 0x000000);
							} else if(y!=subs && j*subs+y>0 && solution[i*subs+x][j*subs+y] && solution[i*subs+x][j*subs+y-1]) {
								int left = size*(i-start)+margin+corridor*x+corridor/2-2;
								int width=5;
								int top = size*j+margin+corridor*y-corridor/2-2;
								int height=corridor+5;
								if(y==0) {
									top -= 2*margin;
									height += 2*margin;
								}
								setRect(bi, left, top, width, height, 0x800000);
							}
						}
						if(y!=subs) {
							if(ewWalls[i*subs+x][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x-1;
								int width = 3;
								int top=size*j+margin+corridor*y;
								int height = corridor;
								if((x==0) && (i!=0)) {
									left -= (margin-1);
									width += (margin-1);
								}
								if((x==subs) && (i!=4)) {
									width += (margin-1);
								}
								setRect(bi, left, top, width, height, 0x000000);
							} else if(x!=subs && i*subs+x>0 && solution[i*subs+x][j*subs+y] && solution[i*subs+x-1][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x-corridor/2-2;
								int width = corridor+5;
								int top = size*j+margin+corridor*y+corridor/2-2;
								int height = 5;
								if(x==0) {
									left -= 2*margin;
									width += 2*margin;
								}
								setRect(bi, left, top, width, height, 0x800000);
							}
						}
						int left=size*(i-start)+margin+corridor*x-1;
						int top=size*j+margin+corridor*y-1;
						int width = 3;
						int height = 3;
						if((x==0) && (i!=0)) {
							left -= (margin-1);
							width += (margin-1);
						}
						if((y==0) && (j!=0)) {
							top -= (margin-1);
							height += (margin-1);
						}
						if((x==subs) && (i!=4)) {
							width += (margin-1);
						}
						if((y==subs) && (j!=4)) {
							height += (margin-1);
						}
						if(!middleOfNowhere(i,j,x,y))
							setRect(bi, left, top, width, height, 0x000000);
						//else
							//setRect(bi, left, top, width, height, 0x808080);
					}
				}
				setRect(bi, size*(i-start), size*j, size+1, 1, 0x808080);
				setRect(bi, size*(i-start), size*j, 1, size+1, 0x808080);
				setRect(bi, size*(i-start+1), size*j, 1, size+1, 0x808080);
				setRect(bi, size*(i-start), size*(j+1), size+1, 1, 0x808080);
			}
		}

		try {
			ImageIO.write(bi, "BMP", new File(fileName));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	boolean middleOfNowhere(int i, int j, int x, int y) {
		if(x!=half && y!=half)
			return false;
		//if(x==0 || y==0 || x==subs || y==subs)
			//return false;
		if(x!=0 && nsWalls[i*subs+x-1][j*subs+y])
			return false;
		if(x!=subs && nsWalls[i*subs+x][j*subs+y])
			return false;
		if(y!=0 && ewWalls[i*subs+x][j*subs+y-1])
			return false;
		if(y!=subs && ewWalls[i*subs+x][j*subs+y])
			return false;
		return true;
	}

	void setRect(BufferedImage bi, int x, int y, int w, int h, int rgb) {
		for(int i=0;i<w;i++)
			for(int j=0;j<h;j++)
				bi.setRGB(x+i,y+j,rgb);
	}

}
