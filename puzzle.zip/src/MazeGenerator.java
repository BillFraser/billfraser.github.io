import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.util.Set;
import java.util.TreeSet;
import java.util.Random;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.util.zip.*;

public class MazeGenerator {

	static final int[] X = {0,1,2,3,4,4,4,4,4,3,2,1,0,0,0,0};
	static final int[] Y = {0,0,0,0,0,1,2,3,4,4,4,4,4,3,2,1};
	static final int[] ROT = {2,3,3,3,3,0,0,0,0,1,1,1,1,2,2,2};

	static final int[] SHAPE_SPIRAL = {26,5,5,5,9,5,5,9,26,5,5,5,9,5,5,9,10,10,12,6,10,9,3,10,10};
	static final int[] SHAPE_SLALOM = {26,5,5,5,9,12,9,12,26,5,5,5,9,12,9,12,10,10,10,10,10,10,10,10,10,10};
	static final int[] SHAPE_LINE = {0,0,0,0,0,0,26,0,0,0,0,0,0,0,26,0,0,0,0,10,10,10,0,0,0};

	static final int MODEL_GRID_SIZE = 5000;
	static final int MODEL_HEIGHT = 3000;

	int subs;
	int half;
	int corridor;
	int margin;
	int size;

	int leftMask;
	int rightMask;
	int mid3Mask;
	int mid1Mask;

	boolean[][][] tunnels;
	boolean[][] nsWalls;
	boolean[][] ewWalls;
	int[][] distance;
	boolean[][] solution;
	int[][] regions;

	Set<Integer> freeze=new TreeSet<>();

	int region;
	int merges;
	int remaining;

	Set<Integer> taken = new TreeSet<>();

	long seed;
	Random random;
	boolean splitMode;
	boolean hard;
	int[] shape;
	boolean threeD;

	java.util.List<int[]> vertices = new java.util.ArrayList<>();
	java.util.List<int[]> triangles = new java.util.ArrayList<>();

	MazeGenerator() {
		this(10, 0, false, true, "spiral", true);
	}

	MazeGenerator(int subs, long seed, boolean splitMode, boolean hard, String shapeName, boolean threeD) {
		if(seed == 0)
			seed = System.nanoTime();
		this.seed = seed;
		random = new Random(seed);
		this.splitMode = splitMode;
		this.hard = hard;
		setShape(shapeName);
		this.threeD = threeD;

		this.subs = subs;
		half = subs/2;
		corridor = 20;
		margin = subs;
		size = subs*corridor + 2*margin;

		leftMask = (1<<subs) - (2<<half);
		rightMask = (1<<(half-1)) - 1;
		mid3Mask = (3<<(half-1));
		mid1Mask = (1<<(half-1));

		tunnels = new boolean[5][5][4];
		nsWalls = new boolean[5*subs][5*subs+1];
		ewWalls = new boolean[5*subs+1][5*subs];
		distance = new int[5*subs][5*subs];
		solution = new boolean[5*subs][5*subs];
		regions = new int[5*subs][5*subs];

		region=1;
		merges=0;
		remaining=(subs*5)*(subs*5)-1;

		for(int i=0;i<subs*5;i++) {
			for(int j=0;j<=subs*5;j++) {
				nsWalls[i][j]=true;
				ewWalls[j][i]=true;
			}
		}
	}

	void setShape(String shapeName) {
		if("spiral".equalsIgnoreCase(shapeName))
			shape = SHAPE_SPIRAL;
		else if("slalom".equalsIgnoreCase(shapeName))
			shape = SHAPE_SLALOM;
		else if("line".equalsIgnoreCase(shapeName))
			shape = SHAPE_LINE;
		else
			throw new RuntimeException("Unknown shape: "+shapeName);
	}

	void setBorder(int[] borders) {
		int[] lookup = new int[16];
		int[] lookup2 = new int[16];
		int link=0;
		int link2=0;
		for(int i=0;i<16;i++) {
			lookup[link]=i;
			link = borders[link];
			lookup2[link2]=i;
			link2 = borders[link2]^1;
		}
		if(link!=0)
			throw new RuntimeException();
		if(link2!=0)
			throw new RuntimeException();
		for(int i=0;i<16;i++) {
			int x = X[i];
			int y = Y[i];
			int rot = ROT[i];
			if(false) {	// Ugly hard-coded slalom
				switch(lookup[link]) {
					case 0:
					case 8:
						tunnels[x][y][(3+rot)%4]=true;
						tunnels[x][y][(1+rot)%4]=true;
						createExit(x,y,rot);
						break;
					case 4:
					case 12:
						tunnels[x][y][(0+rot)%4]=true;
						tunnels[x][y][(3+rot)%4]=true;
						break;
					case 1:
					case 2:
					case 3:
					case 9:
					case 10:
					case 11:
						tunnels[x][y][(0+rot)%4]=true;
						tunnels[x][y][(2+rot)%4]=true;
						break;
					case 5:
					case 7:
					case 13:
					case 15:
						tunnels[x][y][(0+rot)%4]=true;
						tunnels[x][y][(3+rot)%4]=true;
						break;
					case 6:
					case 14:
						tunnels[x][y][(3+rot)%4]=true;
						tunnels[x][y][(2+rot)%4]=true;
						break;
				}
			} else {
				int s = shape[lookup[link]];
				if((s&16)==16) {
					createExit(x,y,rot);
				}
				for(int k=0;k<4;k++) {
					if((s&(1<<k))!=0)
						tunnels[x][y][(k+rot)%4]=true;
				}
			}
			link = borders[link]^1;
		}
		for(int i=0;i<16;i+=2) {
			int value = getValue();
			link=lookup2[i];
			setBoundary(X[link],Y[link],ROT[link],value);
			link=lookup2[i+1];
			setBoundary(X[link],Y[link],ROT[link],value);
		}
	}

	void createExit(int x, int y, int rot) {
		switch(rot) {
			case 0:
				ewWalls[x*subs+subs][y*subs+half]=false;
				ewWalls[x*subs+subs][y*subs+half-1]=false;
				break;
			case 1:
				nsWalls[x*subs+half][y*subs+subs]=false;
				nsWalls[x*subs+half-1][y*subs+subs]=false;
				break;
			case 2:
				ewWalls[x*subs][y*subs+half]=false;
				ewWalls[x*subs][y*subs+half-1]=false;
				break;
			case 3:
				nsWalls[x*subs+half][y*subs]=false;
				nsWalls[x*subs+half-1][y*subs]=false;
				break;
		}
	}

	void setLookups(int[] lookup, int[] dualLookup) {
		int value=0;
		for(int i=0;i<24;i++) {
			if((i%2)==0)
				value = getValue();
			int link = dualLookup[i];
			int x = ((link/4)%3)+1;
			int y = ((link/12)%3)+1;
			int rot = link%4;
			//System.out.println(i+" "+x+" "+y+" "+rot);
			if(false) {
				int parity = (rot + lookup[i])%2;
				if(parity==0) {
					tunnels[x][y][1]=true;
					tunnels[x][y][3]=true;
					if((x==2) && (y==1) && (rot==2)) {
						tunnels[2][2][1]=true;
						tunnels[2][2][3]=true;
					}
				} else {
					tunnels[x][y][0]=true;
					tunnels[x][y][2]=true;
					if((x==2) && (y==1) && (rot==2)) {
						tunnels[2][2][0]=true;
						tunnels[2][2][2]=true;
					}
				}
			} else {
				int rot2 = (rot - (lookup[i]%4) + 4)%4;
				int s = shape[16+lookup[i]/4];
				for(int k=0;k<4;k++) {
					if((s&(1<<k))!=0)
						tunnels[x][y][(k+rot2)%4]=true;
				}
				if((x==2 && y==3 && rot==0) || (x==1 && y==2 && rot==1) || (x==2 && y==1 && rot==2) || (x==3 && y==2 && rot==3)) {
					int link3=lookup[i^1];
					int s2 = shape[16+link3/4];
					//System.out.println(i+ " Special case: "+link3+" "+s2+" "+x+" "+y+" "+rot);
					if((s2 & (1<<(link3%4)))!=0) {
						//System.out.println("Activating: "+((2+rot)%4));
						tunnels[2][2][(2+rot)%4]=true;
					}
				}
			}
			setBoundary(x,y,rot,value);
		}
		//applyTunnels();
		//printMaze(11,false);
	}

	int getValue() {
		for(int i=0;i<200000;i++) {
			int test = (int)(random.nextDouble()*(1<<subs));
			if(i>=100000)
				test=i-100000;
			test = (test | mid3Mask) - (mid1Mask);
			if((test & leftMask)==leftMask)
				continue;
			if((test & rightMask)==rightMask)
				continue;
			if(!taken.contains(test)) {
				taken.add(test);
				return test;
			}
		}
		throw new RuntimeException();
	}

	void setBoundary(int x, int y, int side, int value) {
		for(int k=0;k<subs;k++) {
			if((value & (1<<k))==0) {
				switch(side) {
					case 0:
						clearNSWall(x*subs+k,y*subs);
						break;
					case 1:
						clearEWWall(x*subs+subs,y*subs+k);
						break;
					case 2:
						clearNSWall(x*subs+subs-1-k,y*subs+subs);
						break;
					case 3:
						clearEWWall(x*subs,y*subs+subs-1-k);
						break;
				}
			}
		}
	}

	void clearNSWall(int x, int y) {
		nsWalls[x][y] = false;
		remaining--;
		if(regions[x][y]==0) {
			if(regions[x][y-1]==0) {
				regions[x][y]=region;
				regions[x][y-1]=region;
				region++;
			} else {
				regions[x][y]=regions[x][y-1];
			}
		} else {
			if(regions[x][y-1]==0) {
				regions[x][y-1]=regions[x][y];
			} else if(regions[x][y-1] == regions[x][y]) {
				remaining++;
			} else {
				mergeRegions(regions[x][y-1], regions[x][y]);
			}
		}
	}

	void clearEWWall(int x, int y) {
		ewWalls[x][y] = false;
		remaining--;
		if(regions[x][y]==0) {
			if(regions[x-1][y]==0) {
				regions[x][y]=region;
				regions[x-1][y]=region;
				region++;
			} else {
				regions[x][y]=regions[x-1][y];
			}
		} else {
			if(regions[x-1][y]==0) {
				regions[x-1][y]=regions[x][y];
			} else if(regions[x-1][y] == regions[x][y]) {
				remaining++;
			} else {
				mergeRegions(regions[x-1][y], regions[x][y]);
			}
		}
	}

	void mergeRegions(int r1, int r2) {
		merges++;
		for(int i=0;i<regions.length;i++)
			for(int j=0;j<regions[0].length;j++)
				if(regions[i][j]==r1)
					regions[i][j]=r2;
	}

	void generateMaze() {
		applyTunnels();
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				int r = regions[i*subs+half][j*subs+half];
				if(r==0)
					continue;
				freeze.add(r);
			}
		}
		//System.out.println(freeze);
		if(freeze.size()==1) {
			//System.out.println("Maze has two trivial solutions!");
			throw new RuntimeException("Maze has two trivial solutions!");
		}
		if(hard)
			remaining-=freeze.size();
		long count=0;
		while(remaining>0) {
			int u = random.nextInt(5)*subs + random.nextInt(subs-1)+1;
			int v = random.nextInt(5)*subs + random.nextInt(subs);
			if(random.nextBoolean()) {
				if(hard && (freeze.contains(regions[u][v]) || freeze.contains(regions[u-1][v])))
					continue;
				if(regions[u][v]==0 || regions[u][v] != regions[u-1][v])
					clearEWWall(u,v);
				else
					continue;
			} else {
				if(hard && (freeze.contains(regions[v][u]) || freeze.contains(regions[v][u-1])))
					continue;
				if(regions[v][u]==0 || regions[v][u] != regions[v][u-1])
					clearNSWall(v,u);
				else
					continue;
			}
		}
		if(hard) {
			for(int i=0;i<5;i++) {
				if(!ewWalls[0][subs*i+half])
					clearNSWall(0,subs*i+half-1);
				if(!ewWalls[5*subs][i*subs+half])
					clearNSWall(5*subs-1,i*subs+half+1);
				if(!nsWalls[i*subs+half][5*subs])
					clearEWWall(i*subs+half-1,5*subs-1);
				if(!nsWalls[i*subs+half][1])
					clearEWWall(i*subs+half+1,0);
			}
		}
	}

	void applyTunnels() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				if(tunnels[i][j][0]) {
					for(int k=1;k<=half;k++) {
						clearNSWall(subs*i+half,subs*j+k);
						clearEWWall(subs*i+half,subs*j+k-1);
						clearNSWall(subs*i+half-1,subs*j+k);
					}
				}
				if(tunnels[i][j][1]) {
					for(int k=subs-1;k>=half;k--) {
						clearEWWall(subs*i+k,subs*j+half-1);
						clearNSWall(subs*i+k,subs*j+half);
						clearEWWall(subs*i+k,subs*j+half);
					}
				}
				if(tunnels[i][j][2]) {
					for(int k=subs-1;k>=half;k--) {
						clearNSWall(subs*i+half,subs*j+k);
						clearEWWall(subs*i+half,subs*j+k);
						clearNSWall(subs*i+half-1,subs*j+k);
					}
				}
				if(tunnels[i][j][3]) {
					for(int k=1;k<=half;k++) {
						clearEWWall(subs*i+k,subs*j+half-1);
						clearNSWall(subs*i+k-1,subs*j+half);
						clearEWWall(subs*i+k,subs*j+half);
					}
				}
			}
		}	
	}

	void printMaze(int x, boolean withSolution) {
		if(threeD) {
			for(int i=0;i<1;i++) {
				for(int j=0;j<1;j++) {
					print3D(i,j,subs+"."+x+"."+seed+"."+i+j+".3mf");
				}
			}
			return;
		}
		if(splitMode) {
			printMaze(0,3,subs+"."+x+"."+seed+"A.png");
			printMaze(3,5,subs+"."+x+"."+seed+"B.png");
		} else {
			printMaze(0,5,subs+"."+x+"."+seed+".png");
		}
		
		if(withSolution) {
			if(!solve())
				throw new RuntimeException("Can't solve!");
			printMaze(0,5,subs+"."+x+"."+seed+".answer.png");
		}
	} 

	boolean solve() {
		for(int i=0;i<5;i++) {
			if(!ewWalls[0][subs*i+half]) {
				distance[0][subs*i+half]=1;
				distance[0][subs*i+half-1]=1;
				break;
			}
			if(!ewWalls[5*subs][i*subs+half]) {
				distance[5*subs-1][i*subs+half]=1;
				distance[5*subs-1][i*subs+half-1]=1;
				break;
			}
			if(!nsWalls[i*subs+half][5*subs]) {
				distance[i*subs+half][5*subs-1]=1;
				distance[i*subs+half-1][5*subs-1]=1;
				break;
			}
			if(!nsWalls[i*subs+half][0]) {
				distance[i*subs+half][0]=1;
				distance[i*subs+half-1][0]=1;
				break;
			}
		}
		for(int t=1;t<25*subs*subs;t++) {
			boolean found=false;
			for(int x=0;x<5*subs;x++) {
				for(int y=0;y<5*subs;y++) {
					if(distance[x][y]==t) {
						if(t>1 && nearExit(x,y))
							return updateSolution(x,y);
						found=true;
						if(x>0 && !ewWalls[x][y] && distance[x-1][y]==0)
							distance[x-1][y]=t+1;
						if(x<5*subs-1 && !ewWalls[x+1][y] && distance[x+1][y]==0)
							distance[x+1][y]=t+1;
						if(y>0 && !nsWalls[x][y] && distance[x][y-1]==0)
							distance[x][y-1]=t+1;
						if(y<5*subs-1 && !nsWalls[x][y+1] && distance[x][y+1]==0)
							distance[x][y+1]=t+1;
					}
				}
			}
			if(!found)
				return false;
		}
		return false;

		/* Old code
		if(solution[x][y])
			return false;
		System.out.println(x+" "+y);
		solution[x][y]=true;

		if(nearExit(x,y))
			return true;

		if(canMoveX(x,y,x,x-1))
			return true;
		if(canMoveX(x,y,x+1,x+1))
			return true;
		if(canMoveY(x,y,y,y-1))
			return true;
		if(canMoveY(x,y,y+1,y+1))
			return true;
		solution[x][y]=false;
		return false;
		*/
	}

	boolean updateSolution(int x, int y) {
		for(int t=distance[x][y];t>0;t--) {
			solution[x][y]=true;
			if(t==1)
				return true;
			if(x>0 && !ewWalls[x][y] && distance[x-1][y]==t-1)
				x--;
			else if(x<5*subs-1 && !ewWalls[x+1][y] && distance[x+1][y]==t-1)
				x++;
			else if(y>0 && !nsWalls[x][y] && distance[x][y-1]==t-1)
				y--;
			else if(y<5*subs-1 && !nsWalls[x][y+1] && distance[x][y+1]==t-1)
				y++;
		}
		return false;
	}

	/*
	boolean canMoveX(int x, int y, int checkX, int newX) {
		if((newX<0) || (newX>=5*subs))
			return false;
		if(ewWalls[checkX][y])
			return false;
		if(newX>x && y>0) {
			if(solution[x][y-1] && !nsWalls[newX][y] && !ewWalls[newX][y-1])
				return false;
		}
		if(newX<x && y<5*subs-1) {
			if(solution[x][y+1] && !nsWalls[newX][y+1] && !ewWalls[x][y+1])
				return false;
		}
		return solve(newX,y);
	}

	boolean canMoveY(int x, int y, int checkY, int newY) {
		if((newY<0) || (newY>=5*subs))
			return false;
		if(nsWalls[x][checkY])
			return false;
		if(newY>y && x<5*subs-1) {
			if(solution[x+1][y] && !ewWalls[x+1][newY] && !nsWalls[x+1][newY])
				return false;
		}
		if(newY<y && x>0) {
			if(solution[x-1][y] && !ewWalls[x][newY] && !nsWalls[x-1][y])
				return false;
		}
		return solve(x,newY);
	}
	*/

	boolean nearExit(int x, int y) {
		if(x==0 && !ewWalls[x][y])
			return true;	
		if(y==0 && !nsWalls[x][y])
			return true;	
		if(x==5*subs-1 && !ewWalls[x+1][y])
			return true;	
		if(y==5*subs-1 && !nsWalls[x][y+1])
			return true;
		return false;
	}

	void print3D(int x, int y, String fileName) {
		try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(fileName),10240))) {
			printRels(zos);
			printContentTypes(zos);
			printModel(zos,x,y);
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
	}

	void setupEntry(ZipOutputStream zos, String fileName) throws IOException {
		ZipEntry ze = new ZipEntry(fileName);
		zos.putNextEntry(ze);
	}

	void printContent(ZipOutputStream zos, String text) throws IOException {
		zos.write(text.getBytes());
	}

	void printRels(ZipOutputStream zos) throws IOException {
		setupEntry(zos,"_rels/.rels");
		try (InputStream is = getInputStream(".rels")) {
			is.transferTo(zos);
		}
		zos.closeEntry();
	}

	void printContentTypes(ZipOutputStream zos) throws IOException {
		setupEntry(zos,"[Content_Types].xml");
		try (InputStream is = getInputStream("[Content_Types].xml")) {
			is.transferTo(zos);
		}
		zos.closeEntry();
	}

	InputStream getInputStream(String name) throws IOException {
		if(new File(name).exists())
			return new FileInputStream(name);
		return this.getClass().getClassLoader().getResourceAsStream(name);
	}

	void printModel(ZipOutputStream zos, int x, int y) throws IOException {
		setupEntry(zos,"3D/3dmodel.model");
		try (InputStream is = getInputStream("model.preamble")) {
			is.transferTo(zos);
		}
		calc3DComponents(x,y);
		print3DVertices(zos);
		print3DTriangles(zos);
		try (InputStream is = getInputStream("model.postamble")) {
			is.transferTo(zos);
		}
		zos.closeEntry();
	}

	void calc3DComponents(int x, int y) {
		vertices.clear();
		triangles.clear();
		calcLatticePoints();
		//for(int i=0;i<=subs+2;i+=subs+2)
			//for(int j=0;j<=subs+2;j+=subs+2)
				//calcCornerBlock(i,j);
		for(int i=1;i<=subs;i++) {
			calcEdgeBlock(i,0,x,y);
			calcEdgeBlock(i,subs,x,y);
			calcEdgeBlock(0,i,x,y);
			calcEdgeBlock(subs,i,x,y);
			for(int j=1;j<=subs;j++) {
				calcInteriorBlock(i+1,j+1,x*subs+i,y*subs+j);
			}
		}
	}

	void calcLatticePoints() {
		for(int i=0;i<subs+3;i++) {
			for(int j=0;j<subs+3;j++) {
				vertices.add(new int[] {i*MODEL_GRID_SIZE, j*MODEL_GRID_SIZE, 0});
				vertices.add(new int[] {i*MODEL_GRID_SIZE, j*MODEL_GRID_SIZE, MODEL_HEIGHT});
			}
		}
	}

	void calcEdgeBlock(int x, int y, int xW, int yW) {
		if(nsWalls[xW][yW]) {
			// create BUMP or DENT
			// Need 8+8 new vertices plus some rectangles
		} else {
			// create plain box with raised rail
			// Need 0+8 new vertices plus some rectangles -- with color!
		}
		// for now, just create a blank square!
		//createLatticeBase(x,y);
		//createLatticeRoof(x,y);
		int topBase=x*(subs+3)+y;
		int bottomBase = topBase + (subs+3)*(subs+3);
		calcRectangle(topBase,topBase+1,topBase+subs+4,topBase+subs+3,0);
		calcRectangle(topBase,topBase+1,bottomBase,bottomBase+1,0);
		calcRectangle(bottomBase,bottomBase+subs+3,bottomBase+subs+4,bottomBase+1,0);
	}

	void calcInteriorBlock(int x, int y, int xW, int yW) {
		// for now, just create a blank square!
		int base=x*(subs+3)+y;
		calcRectangle(base,base+3,base+(subs+3)*2,base+(subs+3)*2+2,0);
		calcRectangle(base+1,base+(subs+3)*2+3,base+(subs+3)*2+1,base+3,0);
	}

	// Rectangle must be specified Counter-Clockwise.
	void calcRectangle(int v1, int v2, int v3, int v4, int color) {
		if(color==0) {
			triangles.add(new int[] {v1, v2, v3});
			triangles.add(new int[] {v1, v3, v4});
		} else {
			triangles.add(new int[] {v1, v2, v3, color});
			triangles.add(new int[] {v1, v3, v4, color});
		}
	}

	void print3DVertices(ZipOutputStream zos) throws IOException {
		printContent(zos,"          <vertices>\n");
		for(int[] vertex : vertices) {
			printContent(zos,"          <vertex x=\""+vertex[0]+"\" y=\""+vertex[1]+"\" z=\""+vertex[2]+"\">\n");
		}
		printContent(zos,"          </vertices>\n");
	}

	void print3DTriangles(ZipOutputStream zos) throws IOException {
		printContent(zos,"          <triangles>\n");
		for(int[] triangle : triangles) {
			if(triangle.length==3)
				printContent(zos,"          <triangle x=\""+triangle[0]+"\" y=\""+triangle[1]+"\" z=\""+triangle[2]+"\">\n");
			else
				printContent(zos,"          <triangle x=\""+triangle[0]+"\" y=\""+triangle[1]+"\" z=\""+triangle[2]+"\" pid=\"1\" pindex=\""+triangle[3]+"\">\n");
		}
		printContent(zos,"          </triangles>\n");
	}

	void printMaze(int start, int end, String fileName) {
		BufferedImage bi = new BufferedImage((end-start)*size+1,5*size+1,BufferedImage.TYPE_INT_RGB);
		setRect(bi, 0, 0, bi.getWidth(), bi.getHeight(), 0xFFFFFF);

		for(int i=start;i<end;i++) {
			for(int j=0;j<5;j++) {
				for(int x=0;x<=subs;x++) {
					for(int y=0;y<=subs;y++) {
						if(x!=subs) {
							if(nsWalls[i*subs+x][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x;
								int width = corridor;
								int top=size*j+margin+corridor*y-1;
								int height = 3;
								if((y==0) && (j!=0)) {
									top -= (margin-1);
									height += (margin-1);
								}
								if((y==subs) && (j!=4)) {
									height += (margin-1);
								}
								setRect(bi, left, top, width, height, 0x000000);
							} else if(y!=subs && j*subs+y>0 && solution[i*subs+x][j*subs+y] && solution[i*subs+x][j*subs+y-1]) {
								int left = size*(i-start)+margin+corridor*x+corridor/2-2;
								int width=5;
								int top = size*j+margin+corridor*y-corridor/2-2;
								int height=corridor+5;
								if(y==0) {
									top -= 2*margin;
									height += 2*margin;
								}
								setRect(bi, left, top, width, height, 0x800000);
							}
						}
						if(y!=subs) {
							if(ewWalls[i*subs+x][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x-1;
								int width = 3;
								int top=size*j+margin+corridor*y;
								int height = corridor;
								if((x==0) && (i!=0)) {
									left -= (margin-1);
									width += (margin-1);
								}
								if((x==subs) && (i!=4)) {
									width += (margin-1);
								}
								setRect(bi, left, top, width, height, 0x000000);
							} else if(x!=subs && i*subs+x>0 && solution[i*subs+x][j*subs+y] && solution[i*subs+x-1][j*subs+y]) {
								int left=size*(i-start)+margin+corridor*x-corridor/2-2;
								int width = corridor+5;
								int top = size*j+margin+corridor*y+corridor/2-2;
								int height = 5;
								if(x==0) {
									left -= 2*margin;
									width += 2*margin;
								}
								setRect(bi, left, top, width, height, 0x800000);
							}
						}
						int left=size*(i-start)+margin+corridor*x-1;
						int top=size*j+margin+corridor*y-1;
						int width = 3;
						int height = 3;
						if((x==0) && (i!=0)) {
							left -= (margin-1);
							width += (margin-1);
						}
						if((y==0) && (j!=0)) {
							top -= (margin-1);
							height += (margin-1);
						}
						if((x==subs) && (i!=4)) {
							width += (margin-1);
						}
						if((y==subs) && (j!=4)) {
							height += (margin-1);
						}
						if(!middleOfNowhere(i,j,x,y))
							setRect(bi, left, top, width, height, 0x000000);
						//else
							//setRect(bi, left, top, width, height, 0x808080);
					}
				}
				setRect(bi, size*(i-start), size*j, size+1, 1, 0x808080);
				setRect(bi, size*(i-start), size*j, 1, size+1, 0x808080);
				setRect(bi, size*(i-start+1), size*j, 1, size+1, 0x808080);
				setRect(bi, size*(i-start), size*(j+1), size+1, 1, 0x808080);
			}
		}

		try {
			ImageIO.write(bi, "BMP", new File(fileName));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	boolean middleOfNowhere(int i, int j, int x, int y) {
		if(x!=half && y!=half)
			return false;
		//if(x==0 || y==0 || x==subs || y==subs)
			//return false;
		if(x!=0 && nsWalls[i*subs+x-1][j*subs+y])
			return false;
		if(x!=subs && nsWalls[i*subs+x][j*subs+y])
			return false;
		if(y!=0 && ewWalls[i*subs+x][j*subs+y-1])
			return false;
		if(y!=subs && ewWalls[i*subs+x][j*subs+y])
			return false;
		return true;
	}

	void setRect(BufferedImage bi, int x, int y, int w, int h, int rgb) {
		for(int i=0;i<w;i++)
			for(int j=0;j<h;j++)
				bi.setRGB(x+i,y+j,rgb);
	}

}
