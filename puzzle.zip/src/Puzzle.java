/*
	@Author William Fraser
	Covered by GNU AGPL: (http://BillFraser.github.io/LICENSE.md)

	Code to generate a jigsaw puzzle with the following constraints:

	5x5
	All interior shapes occur exactly twice
	There are exactly two solutions
	No pair of edges connected in one solution is also connected in the other

	This challenge was posed by Matt Parker in the following video:

	https://www.youtube.com/watch?v=b5nElEbbnfU&t=0s

*/

import java.util.*;

public class Puzzle {
	static final int SIZE=3;	// Note that a size of N creates a (N+2) by (N+2) puzzle
	static final int BORDER_SIZE=4*(SIZE+1);
	static final int BORDER_COUNT=BORDER_SIZE/2;
	static final int MARGIN_SIZE=4*SIZE;
	static final int INTERIOR_COUNT=2*SIZE*(SIZE+1);

	static final long MARGIN_MASK = ((1L<<INTERIOR_COUNT)-1L) | (((1L<<24)<<INTERIOR_COUNT)-(1L<<24)) | (((1L<<48)<<(SIZE*SIZE))-(1L<<48));

	static final int[] DELTA = {-SIZE,1,SIZE,-1};
	static final int[] ROTATE = {2,3,0,1};

	static int[] borders = new int[BORDER_SIZE];		// each border piece is identified by its index and its other side

	static int[][] interior = new int[SIZE*SIZE][4];	// The solving grid for the initial puzzle.
	static int[][] dualInterior = new int[SIZE*SIZE][4];	// The solving grid for the dual puzzle.
	static int[][] testInterior = new int[SIZE*SIZE][4];	// The solving grid for the only2.

	static int[] placement = new int[SIZE*SIZE];		// The new location and rotation of a given piece going from regular to dual.
	static int[] dualPlacement = new int[SIZE*SIZE];	// The new location and rotation of a given piece going from dual to regular.

	static int[] lookup = new int[INTERIOR_COUNT]; 		// The placement and rotation of a given positive interior edge.
	static int[] dualLookup = new int[INTERIOR_COUNT]; 	// The placement and rotation of a given positive interior edge of the dual.

	static char[][][] pieces = makeGrid();			// The printing grid for the initial puzzle.
	static char[][][] dualPieces = makeGrid();		// The printing grid for the dual puzzle.
	static char[][][] testPieces = makeGrid();		// The printing grid for only2.

	static MazeGenerator maze;				// Used to generate the image for the jigsaw puzzle

	static int mappingCount;
	static int[][] mappings = new int[1<<(BORDER_SIZE/2)][MARGIN_SIZE];	// The way the margin is permuted given a way of solving the border.

	static int[][] marginMap = generateMarginMap(); 	// The location and rotation of the margin edges

	static int answers;
	static int startAnswers;
	static int active;

	static int borderSymmetryFlag;

	static boolean printGrid;
	static boolean printArray;

	static Set<String> canonicalSet = new HashSet<>();	// A list of canonical labellings of all variants of each accepted solution

	public static void main(String[] args) {
		if(args.length==0) {
			active = (int)(Math.random()*600);
 			maze = new MazeGenerator();
		} else if("list".equalsIgnoreCase(args[0])) {
			for(int i=1;i<args.length;i++) {
				if("grid".equalsIgnoreCase(args[i]))
					printGrid = true;
				if("array".equalsIgnoreCase(args[i]))
					printArray = true;
			}
		} else {
			boolean puzzle = "puzzle".equalsIgnoreCase(args[0]);
			boolean split = "split".equalsIgnoreCase(args[0]);
			if(puzzle || split) {
				int subs = Integer.parseInt(args[1]);
				active = Integer.parseInt(args[2]);
				if(active<0)
					active=(int)(Math.random()*600);
				long seed = Long.parseLong(args[3]);
				boolean hard=true;
				String shapeName="line";
				boolean threeD=false;
				for(int i=4;i<args.length;i++) {
					String s = args[i];
					if("hard".equalsIgnoreCase(s))
						hard=true;
					else if("easy".equalsIgnoreCase(s))
						hard=false;
					else if("3d".equalsIgnoreCase(s) || "threeD".equalsIgnoreCase(s))
						threeD=true;
					else
						shapeName=s;
				}
				maze = new MazeGenerator(subs,seed,split,hard,shapeName,threeD);
			} else {
				throw new RuntimeException("Unknown verb: "+args[0]);
			}
		}
		borders[0]=2;
		iterateBorder(2,(1<<borders.length)-1-0x5,2);
		if(printGrid || printArray) {
			System.out.println("Total answers: "+answers);
		}
		//for(String s : canonicalSet) {
			//System.out.println(s);
		//}
	}

	static void iterateBorder(int index, int mask, int limit) {
		//for(int i=0;i<BORDER_SIZE;i++)
			//System.out.print(borders[i]+" ");
		//System.out.println();
		//System.out.println(index+" "+Integer.toString(mask,16)+" "+limit);
		if(mask==0) {
			borders[index]=0;
			testBorder();
			return;
		}
		for(int k=0;k<limit*2;k+=2) {
			if(k/2==index/2)
				continue;
			if((mask & (1<<k))!=0) {
				borders[index]=k;
				iterateBorder(k,mask - (1<<k),limit);
			} else if((mask & (2<<k))!=0) {
				borders[index]=k+1;
				iterateBorder(k+1,mask - (2<<k),limit);
			}
		}
		if(limit<BORDER_COUNT) {
			borders[index]=limit*2;
			iterateBorder(limit*2,mask - (1<<(limit*2)),limit+1);
		}
	}

	static boolean isPreemptedBorder() {
		if(false)
			return false;
		borderSymmetryFlag=0;
		int[] values = new int[BORDER_SIZE];
		int link=0;
		for(int i=0;i<BORDER_SIZE;i++) {
			values[i]=link;
			link=borders[link];
		}
		if(isPreemptedBorder(values,BORDER_SIZE/4,1,1))
			return true;
		if(isPreemptedBorder(values,BORDER_SIZE/2,1,2))
			return true;
		if(isPreemptedBorder(values,3*BORDER_SIZE/4,1,3))
			return true;
		if(isPreemptedBorder(values,1,-1,4))
			return true;
		if(isPreemptedBorder(values,BORDER_SIZE/4+1,-1,5))
			return true;
		if(isPreemptedBorder(values,BORDER_SIZE/2+1,-1,6))
			return true;
		if(isPreemptedBorder(values,3*BORDER_SIZE/4+1,-1,7))
			return true;
		return false;
	}

	static boolean isPreemptedBorder(int[] values, int start, int direction, int index) {
		int[] map = new int[BORDER_SIZE/2];
		for(int i=0;i<map.length;i++)
			map[i]=-1;
		int min=0;

		for(int i=0;i<BORDER_SIZE;i++) {
			int v=values[(start+i*direction+BORDER_SIZE)%BORDER_SIZE];
			int m=map[v/2];
			if(m<0) {
				m=2*min;
				map[v/2]=m+1;
				min++;
			}
			if(m < values[i])
				return true;
			else if(m > values[i])
				return false;
		}

		borderSymmetryFlag |= (1<<index);
		if(false) {
			System.out.print("Equality: "+start+" "+direction+": ");
			for(int v : values)
				System.out.print(" "+v);
			System.out.println();
		}
		return false;
	}

	static boolean isPreemptedMargin() {
		if(false)
			return false;
		if(borderSymmetryFlag==0)
			return false;
if(answers>=5) {
//System.out.println("ANSWERS: "+borderSymmetryFlag);
}
		if(isPreemptedMargin(MARGIN_SIZE/4,1,1))
			return true;
		if(isPreemptedMargin(MARGIN_SIZE/2,1,2))
			return true;
		if(isPreemptedMargin(3*MARGIN_SIZE/4,1,3))
			return true;
		if(isPreemptedMargin(MARGIN_SIZE-1,-1,4))
			return true;
		if(isPreemptedMargin(MARGIN_SIZE/4-1,-1,5))
			return true;
		if(isPreemptedMargin(MARGIN_SIZE/2-1,-1,6))
			return true;
		if(isPreemptedMargin(3*MARGIN_SIZE/4-1,-1,7))
			return true;
if(answers>=7) {
//System.out.println("ANSWERS!");
//System.exit(0);
}
		return false;
	}

	static boolean isPreemptedMargin(int start, int direction, int index) {
		if((borderSymmetryFlag & (1<<index))==0)
			return false;

		int[] map = new int[INTERIOR_COUNT/2+1];
		int min=1;
	
		for(int i=0;i<MARGIN_SIZE;i++) {
			int loc1=marginMap[i][0];
			int rot1=marginMap[i][1];
			int i2=(start+i*direction+MARGIN_SIZE)%MARGIN_SIZE;
			int loc2=marginMap[i2][0];
			int rot2=marginMap[i2][1];

			int v1=interior[loc1][rot1];
			int v2=interior[loc2][rot2];

			int m=map[v2/2];
			if(m==0) {
				m=2*min;
				map[v2/2]=m+1;
				min++;
			}
			if(m < v1) {
				//System.out.println("Preempted:  "+i+" "+m+" "+v1);
				return true;
			}
			else if(m > v1)
				return false;
		}
		//System.out.print("Equality: "+start+" "+direction+": "+index);
		return false;
	}

	static void testBorder() {
		int link=0;
		int link2=0;
		int corner=0;
		int corner2=0;
		int offset=0;
		for(int i=0;i<BORDER_SIZE;i++) {
			if((i%(SIZE+1))==0) {
				corner |= (1<<link);
			}
			if(i!=0 && link==0)
				return;
			link=borders[link];
		}
		if(link!=0)
			throw new RuntimeException();
		if(!fillMapping(0,0,corner))
			throw new RuntimeException();
		if(!fillMapping(1,-1,corner))
			return;
		if(isPreemptedBorder())
			return;
		for(int i=0;i<lookup.length;i++) {
			lookup[i]=-1;
			dualLookup[i]=-1;
		}
		if(SIZE!=0) {
			for(int i=0;i<BORDER_COUNT;i+=2) {
				if((corner & (3<<i))==(3<<i)) {
					if((borders[i] ^ borders[i+1])==1)
						return;
				}
			}
			mappingCount=2;
			for(int i=1;i<mappings.length-1;i++) {
				if(fillMapping(mappingCount,i,corner)) {
					if(false) {
						System.out.println("Good: "+i);
						fillGridBorder(testPieces,i);
						printGrid(testPieces);
					}
					mappingCount++;
				} else {
					//System.out.println("ACK: "+i+" "+mappingCount);
				}
			}
		}
		//System.out.println("Mapping count: "+mappingCount);
		fillGridBorder(pieces, 0);
		fillGridBorder(dualPieces, -1);
		if(false) {
			for(int i=0;i<borders.length;i++)
				System.out.print(borders[i]+" ");
			System.out.println();
		}
		if(false) {
			for(int i=0;i<mappings[1].length;i++)
				System.out.print(mappings[1][i]+",");
			System.out.println();
		}
		if(true && false) {
			System.out.println("About to call iterateMargin");
			printGrid(pieces);
			printGrid(dualPieces);
		}
		iterateMargin(0, MARGIN_MASK, 0);
		if(false && answers>0) {
			System.out.println("Answers so far: "+answers);
			System.exit(0);
		}
	}

	static boolean fillMapping(int index, int skew, int targetCorner) {
		//System.out.println("Calling fillMapping "+skew);
		int corner=0;
		int link=0;
		int offset=0;
		for(int i=0;i<BORDER_SIZE;i++) {
			if((i%(SIZE+1))==0) {
				corner |= (1<<link);
			} else {
				int link2=0;
				int offset2=0;
				for(int j=0;j<BORDER_SIZE;j++) {
					if((j%(SIZE+1))==0) {
					} else {
						if(link==link2)
							mappings[index][offset2]=offset;
						offset2++;
					}
					link2=borders[link2];
				}
				offset++;
			}
			if(i!=0 && link==0)
				return false;
			link=borders[link]^((skew>>(borders[link]/2))&1);
			//System.out.print(link+" ");
		}
		if(link!=0)
			throw new RuntimeException();
		if(corner!=targetCorner)
			return false;
		return true;
	}

	static void iterateMargin(int index, long mask, int limit) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		//System.out.println("Iterate Margin: "+index+", "+Long.toString(mask,16)+", "+limit);
		if(index==MARGIN_SIZE) {
			int save1 = lookup[1];
			if((mask&2)!=0 && lookup[1]!=-1)
				throw new RuntimeException();
			testMargin(mask, limit);
			resetPuzzle(mask);
			if((mask&2)!=0 && lookup[1]!=-1)
				throw new RuntimeException();
			if(lookup[1]!=save1)
				throw new RuntimeException();
			return;
		}
if(index==1 && limit!=2)
throw new RuntimeException();
		for(int k=0;k<limit;k+=2) {
			if(index==0)
				throw new RuntimeException();
			if((mask & (1L<<k))!=0) {
if(index==1)
throw new RuntimeException();
				int save1 = lookup[1];
				addMargin(index, k);
				int save2 = lookup[1];
				iterateMargin(index+1, mask - (1L<<k) - ((2L<<24)<<k), limit);
				if(lookup[1]!=save2)
					throw new RuntimeException();
				removeMargin(index, k);
				if(lookup[1]!=save1)
					throw new RuntimeException();
			} else if((mask & (2L<<k))!=0) {
				int save1 = lookup[1];
				addMargin(index, k+1);
				int save2 = lookup[1];
				iterateMargin(index+1, mask - (2L<<k) - ((1L<<24)<<k), limit);
				if(lookup[1]!=save2)
					throw new RuntimeException();
				removeMargin(index, k+1);
				if(lookup[1]!=save1)
					throw new RuntimeException();
			} else {
if(index==1)
throw new RuntimeException();
			}
		}
		if(limit<INTERIOR_COUNT) {
			int save1 = lookup[1];
			addMargin(index, limit);
			int save2 = lookup[1];
			iterateMargin(index+1, mask - (1L<<limit) - ((2L<<24)<<limit), limit+2);
			if(lookup[1]!=save2)
				throw new RuntimeException("index: "+index);
			removeMargin(index, limit);
			if(lookup[1]!=save1) {
				printPuzzle(interior);
				System.out.println(index+" "+limit);
				throw new RuntimeException("index: "+index);
			}
		}
	}

	static void resetPuzzle(long mask) {
		if(false) {
			System.out.println("resetPuzzle: "+Long.toString(mask,16));
			printPuzzle(interior);
			printPuzzle(dualInterior);
		}
		for(int i=0;i<interior.length;i++) {
			for(int j=0;j<4;j++) {
				int v = interior[i][j];
				if(v==0)
					continue;
				int v2;
				if(v>0)
					v2=v-2;
				else
					v2=-v-2;
				if((mask & (1L<<v2))!=0) {
					//System.out.println("Setting "+i+", "+j+" to zero from "+v+" "+v2);
					interior[i][j]=0;
					if(v>0) {
						lookup[v2]=-1;
					}
				}
			}
		}
		for(int i=0;i<interior.length;i++) {
			for(int j=0;j<4;j++) {
				int v = dualInterior[i][j];
				if(v==0)
					continue;
				int v2;
				if(v>0)
					v2=v-2;
				else
					v2=(-v-2)^1;
				if((mask & ((1L<<24)<<v2))!=0) {
					dualInterior[i][j]=0;
					if(v>0)
						dualLookup[v2]=-1;
				}
			}
		}
		for(int i=0;i<placement.length;i++) {
			if((mask & ((1L<<48)<<i))!=0 && placement[i]!=-1) {
				dualPlacement[placement[i]>>2]=-1;
				placement[i]=-1;
			}
		}
		if(false) {
			printPuzzle(interior);
			printPuzzle(dualInterior);
		}
	}

	static void addMargin(int index, int k) {
		//System.out.println("Calling addMargin: "+index+" "+mappings[1][index]+" "+k);
		addMarginToGrid(index, k, pieces, interior, lookup);
		addMarginToGrid(mappings[1][index], k^1, dualPieces, dualInterior, dualLookup);
	}

	static void removeMargin(int index, int k) {
		//System.out.println("Calling removeMargin: "+index+" "+mappings[1][index]+" "+k);
		removeMarginFromGrid(index, k, pieces, interior, lookup);
		removeMarginFromGrid(mappings[1][index], k^1, dualPieces, dualInterior, dualLookup);
	}

	static void addMarginToGrid(int index, int value, char[][][] grid, int[][] puzzle, int[] lookup) {
		if(index<SIZE) {
			grid[index+1][0][2]=(char)('A'+2+SIZE*2+value/2);
			grid[index+1][1][0]=(char)('a'+2+SIZE*2+value/2);
			puzzle[index][0]=2+value;
			lookup[value] = index<<2;
		} else if(index<2*SIZE) {
			grid[SIZE+1][index+1-SIZE][3]=(char)('A'+2+SIZE*2+value/2);
			grid[SIZE][index+1-SIZE][1]=(char)('a'+2+SIZE*2+value/2);
			//System.out.println("<<<<<"+index+" "+(SIZE-1+SIZE*(index-SIZE)));
			puzzle[SIZE-1+SIZE*(index-SIZE)][1]=2+value;
			lookup[value] = ((SIZE-1+SIZE*(index-SIZE))<<2)+1;
		} else if(index<3*SIZE) {
			grid[3*SIZE-index][SIZE+1][0]=(char)('A'+2+SIZE*2+value/2);
			grid[3*SIZE-index][SIZE][2]=(char)('a'+2+SIZE*2+value/2);
			puzzle[SIZE*SIZE-1-(index-2*SIZE)][2]=2+value;
			lookup[value] = ((SIZE*SIZE-1-(index-2*SIZE))<<2)+2;
		} else {
			grid[0][4*SIZE-index][1]=(char)('A'+2+SIZE*2+value/2);
			grid[1][4*SIZE-index][3]=(char)('a'+2+SIZE*2+value/2);
			puzzle[SIZE*(SIZE-1)-SIZE*(index-3*SIZE)][3]=2+value;
			lookup[value] = ((SIZE*(SIZE-1)-SIZE*(index-3*SIZE))<<2)+3;
		}
	}

	static void removeMarginFromGrid(int index, int value, char[][][] grid, int[][] puzzle, int[] lookup) {
		if(index<SIZE) {
			grid[index+1][0][2]=' ';
			grid[index+1][1][0]=' ';
			if(puzzle[index][0] != 2+value)
				throw new RuntimeException();
			puzzle[index][0]=0;
			lookup[value] = -1;
		} else if(index<2*SIZE) {
			grid[SIZE+1][index+1-SIZE][3]=' ';
			grid[SIZE][index+1-SIZE][1]=' ';
			//System.out.println(">>>>>"+index+" "+(SIZE-1+SIZE*(index-SIZE)));
			if(puzzle[SIZE-1+SIZE*(index-SIZE)][1] != 2+value)
				throw new RuntimeException(puzzle[SIZE-1+SIZE*(index-SIZE)][1]+" != "+(2+value));
			puzzle[SIZE-1+SIZE*(index-SIZE)][1]=0;
			lookup[value] = -1;
		} else if(index<3*SIZE) {
			grid[3*SIZE-index][SIZE+1][0]=' ';
			grid[3*SIZE-index][SIZE][2]=' ';
			if(puzzle[SIZE*SIZE-1-(index-2*SIZE)][2] != 2+value)
				throw new RuntimeException();
			puzzle[SIZE*SIZE-1-(index-2*SIZE)][2]=0;
			lookup[value] = -1;
		} else {
			grid[0][4*SIZE-index][1]=' ';
			grid[1][4*SIZE-index][3]=' ';
			if(puzzle[SIZE*(SIZE-1)-SIZE*(index-3*SIZE)][3] != 2+value)
				throw new RuntimeException();
			puzzle[SIZE*(SIZE-1)-SIZE*(index-3*SIZE)][3]=0;
			lookup[value] = -1;
		}
	}

	static void testMargin(long mask, int limit) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		if(isPreemptedMargin())
			return;
		for(int i=0;i<placement.length;i++)
			placement[i]=-1;
		for(int i=0;i<placement.length;i++)
			dualPlacement[i]=-1;
		//System.out.println("testMargin");
		for(int i=0;i<limit;i++) {
			if((mask & ((1L<<i) | ((1L<<24)<<i)))==0) {
				if((mask&2)!=0 && lookup[1]!=-1)
					throw new RuntimeException();
				mask = connect(i+2,mask);
				if(mask<0)
					return;
			}
		}
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		startAnswers = answers;
		iterateInterior(mask, limit, 0);
		//if(limit<INTERIOR_COUNT) {
		//}
		//System.exit(0);
	}

	static void iterateInterior(long mask, int limit, int index) {
		long newMask;
		while(index<SIZE*SIZE*4) {
			int i=index>>2;
			int j=index%4;
			if(interior[i][j]==0) {
				for(int k=0;k<limit;k+=2) {
					if((mask & (1L<<k))!=0) {
						newMask = setValue(mask,i,j,k+2);
						if(newMask != -1)
							iterateInterior(newMask,limit,index+1);
						resetPuzzle(mask);

						newMask = setValue(mask,i,j,-k-2);
						if(newMask != -1)
							iterateInterior(newMask,limit,index+1);
						resetPuzzle(mask);
					} else if((mask & (2L<<k))!=0) {
						newMask = setValue(mask,i,j,k+3);
						if(newMask != -1)
							iterateInterior(newMask,limit,index+1);
						resetPuzzle(mask);

						newMask = setValue(mask,i,j,-k-3);
						if(newMask != -1)
							iterateInterior(newMask,limit,index+1);
						resetPuzzle(mask);
					}
				}
				if(limit<INTERIOR_COUNT) {
					newMask = setValue(mask,i,j,limit+2);
					if(newMask != -1)
						iterateInterior(newMask,limit+2,index+1);
					resetPuzzle(mask);
				}
				return;
			}
			index++;
		}
		if(duplicateSolution())
			return;
		if(only2()) {
			if(false && answers==16) {
				printPuzzle(interior);
				fillGridInterior(pieces, interior);
				printGrid(pieces);
				fillGridInterior(dualPieces, dualInterior);
				printGrid(dualPieces);
				if(false) {
					for(int i=0;i<mappings.length;i++) {
						System.out.println("Showing "+i);
						fillGridBorder(testPieces,i);
						if(testPieces[0][1][0]=='A')
							printGrid(testPieces);
					}
					System.exit(0);
				}
			}
			if(printGrid || printArray) {
				System.out.println("Solution "+answers+":");
				fillGridInterior(pieces, interior);
				fillGridInterior(dualPieces, dualInterior);
				if(printGrid) {
					printGrid(pieces);
					printGrid(dualPieces);
				}
				if(printArray) {
					printArray(pieces);
					printArray(dualPieces);
				}
			}
			if(!printGrid && !printArray && answers==active) {
				if(isAdmissible()) {
					if(false) {
						System.out.println("Solution "+answers+":");
						fillGridInterior(pieces, interior);
						printGrid(pieces);
						fillGridInterior(dualPieces, dualInterior);
						printGrid(dualPieces);
					}
					maze.setBorder(borders);
					maze.setLookups(lookup,dualLookup);
					maze.generateMaze();
					maze.printMaze(answers,true);
					System.exit(0);
				} else {
					active++;
				}
			}
			answers++;
		} else {
			//System.out.println("Rejected!");
		}
	}

	static boolean duplicateSolution() {
		if(false)
			return false;
		fillGridInterior(pieces, interior);
//if(answers==0)
//System.out.println("0: "+getCanonical(pieces,1,true));
//if(answers==0)
//System.exit(0);
//if(answers==5)
//System.out.println("5: "+getCanonical(pieces,0,false));

if(answers<6) {
//System.out.println(getCanonical(pieces,0,false));
} else {
//System.out.println(canonicalSet);
//System.exit(0);
}
		if(!canonicalSet.add(getCanonical(pieces,0,false)))
			return true;
		canonicalSet.add(getCanonical(pieces,1,false));
		canonicalSet.add(getCanonical(pieces,2,false));
		canonicalSet.add(getCanonical(pieces,3,false));
		canonicalSet.add(getCanonical(pieces,0,true));
		canonicalSet.add(getCanonical(pieces,1,true));
		canonicalSet.add(getCanonical(pieces,2,true));
		canonicalSet.add(getCanonical(pieces,3,true));

		fillGridInterior(dualPieces, dualInterior);
		canonicalSet.add(getCanonical(dualPieces,0,false));
		canonicalSet.add(getCanonical(dualPieces,1,false));
		canonicalSet.add(getCanonical(dualPieces,2,false));
		canonicalSet.add(getCanonical(dualPieces,3,false));
		canonicalSet.add(getCanonical(dualPieces,0,true));
		canonicalSet.add(getCanonical(dualPieces,1,true));
		canonicalSet.add(getCanonical(dualPieces,2,true));
		canonicalSet.add(getCanonical(dualPieces,3,true));
//System.out.println(canonicalSet.size());
		return false;
	}

	static String getCanonical(char[][][] pieces,int rot, boolean flip) {
		char[][][] newPieces = new char[5][5][4];
		char[] map = new char[255];
		StringBuffer sb = new StringBuffer(60);
		char min='A';
//printGrid(pieces);
//System.out.println(">>>>> "+rot+" "+flip);
		for(int j=0;j<SIZE+2;j++) {
			for(int i=0;i<SIZE+2;i++) {
				int x=calcX(i,j,rot,flip);
				int y=calcY(i,j,rot,flip);
				for(int k=0;k<4;k++) {
					int r=(flip?((k^3)+4-rot):(k+4-rot))%4;
					char p=pieces[x][y][r];
					newPieces[i][j][k]=p;
					if(p=='|' || p=='-')
						continue;
//System.out.println(i+" "+j+" "+k+" "+x+" "+y+" "+r);
					char m = map[p];
					if(m==0) {
						m=min;
						map[p]=min;
						if(Character.isUpperCase(p)) {
							map[Character.toLowerCase(p)]=Character.toLowerCase(min);
						} else {
							map[Character.toUpperCase(p)]=Character.toLowerCase(min);
						}
						min++;
					}
					sb.append(m);
				}
			}
		}
//printGrid(newPieces);
//System.out.println(sb);
		return sb.toString();
	}

	static int calcX(int i, int j, int rot, boolean flip) {
		if(flip)
			return calcY(i,j,(4-rot)%4,false);
		if(rot>=2) {
			return calcX(SIZE+1-i,SIZE+1-j,rot-2,flip);
		}
		if(rot>=1) {
			return calcY(SIZE+1-i,j,rot-1,flip);
		}
		return i;
	}

	static int calcY(int i, int j, int rot, boolean flip) {
		if(flip)
			return calcX(i,j,(4-rot)%4,false);
		if(rot>=2) {
			return calcY(SIZE+1-i,SIZE+1-j,rot-2,flip);
		}
		if(rot>=1) {
			return calcX(SIZE+1-i,j,rot-1,flip);
		}
		return j;
	}

	/* Debug function, trying to get a particular type of puzzle for testing purposes -- not used in production */
	static boolean isAdmissible() {
		if(true)
			return true;
		if(pieces[4][4][0]!=dualPieces[4][4][0] || pieces[4][4][3]!=dualPieces[4][4][3]) 
			return false;
		if(pieces[0][0][2]==pieces[0][2][2] && pieces[4][1][2]==pieces[4][3][2])
			return true;
		if(pieces[0][0][2]==pieces[4][1][2] && pieces[0][2][2]==pieces[4][3][2])
			return true;
		if(pieces[0][0][2]==pieces[4][3][2] && pieces[4][1][2]==pieces[0][2][2])
			return true;
		return false;
	}

	static boolean only2() {
		fillTestMargin(0);
		if(!checkFirst1(0,(1<<(SIZE*SIZE))-1))
			return false;
		fillTestMargin(1);
		if(!checkLast1(0,(1<<(SIZE*SIZE))-1))
			return false;
		for(int i=2;i<mappingCount;i++) {
			fillTestMargin(i);
			if(!check0(0,(1<<(SIZE*SIZE))-1))
				return false;
		}
		return true;
	}

	static boolean checkFirst1(int index, int mask) {
		if(index==SIZE*SIZE) {
			if(mask!=0)
				throw new RuntimeException();
			return true;
		}
		int newMask = placeTestPiece(index,0,mask);
		if(newMask>=0) {
			boolean retval = checkFirst1(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		} else {
			throw new RuntimeException();
		}
		newMask = placeTestPiece(index,1,mask);
		if(newMask>=0) {
			boolean retval = check0(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		}
		return true;
	}

	static boolean checkLast1(int index, int mask) {
		if(index==SIZE*SIZE) {
			if(mask!=0)
				throw new RuntimeException();
			return true;
		}
		int newMask = placeTestPiece(index,0,mask);
		if(newMask>=0) {
			boolean retval = check0(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		}
		newMask = placeTestPiece(index,1,mask);
		if(newMask>=0) {
			boolean retval = checkLast1(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		} else {
			throw new RuntimeException();
		}
		return true;
	}

	static boolean check0(int index, int mask) {
		if(index==SIZE*SIZE) {
			if(mask!=0)
				throw new RuntimeException();
			return false;
		}
		int newMask = placeTestPiece(index,0,mask);
		if(newMask>=0) {
			boolean retval = check0(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		}
		newMask = placeTestPiece(index,1,mask);
		if(newMask>=0) {
			boolean retval = check0(index+1, newMask);
			removeTestPiece(index);
			if(!retval)
				return false;
		}
		return true;
	}

	static int placeTestPiece(int index, int skew, int mask) {
		int location;
		int rotation;
		int piece = testInterior[index][0];
//System.out.println("placeTestPiece: "+index+" "+skew+" "+mask+" "+piece);
		if(piece>0) {
			int locrot = lookup[(piece^skew)-2];

			location = locrot>>2;
			rotation = locrot % 4;
		} else {
			int locrot = lookup[((-piece)^skew)-2];

			location = locrot>>2;
			rotation = locrot % 4;
		
			switch(rotation) {
				case 0:
					if(location/SIZE == 0)
						return -1;
					break;
				case 1:
					if(location%SIZE == SIZE-1)
						return -1;
					break;
				case 2:
					if(location/SIZE == SIZE-1)
						return -1;
					break;
				case 3:
					if(location%SIZE == 0)
						return -1;
					break;
			}
			location = location + DELTA[rotation];
			rotation = ROTATE[rotation];
		}
//System.out.println(location+" "+rotation);
		if((mask & (1<<location))==0)
			return -1;
		
		if(piece>0) {
			if(testInterior[index][0] != (interior[location][rotation]^skew))
				throw new RuntimeException();
		} else {
			if(testInterior[index][0] != (-((-interior[location][rotation])^skew))) {
				printPuzzle(testInterior);
				System.out.println(testInterior[index][0]+" compares to "+interior[location][rotation]+"  via "+skew);
				throw new RuntimeException();
			}
		}
		if(!equivalent(testInterior[index][3], interior[location][(rotation+3)%4]))
			return -1;

		if((index%SIZE)==SIZE-1) {
			if(!equivalent(testInterior[index][1], interior[location][(rotation+1)%4]))
				return -1;
		} else {
			int side = interior[location][(rotation+1)%4];
			testInterior[index][1] = side;
			testInterior[index+1][3] = -side;
		}
		if((index/SIZE)==SIZE-1) {
			if(!equivalent(testInterior[index][2], interior[location][(rotation+2)%4])) {
				if((index%SIZE)!=SIZE-1) {
					testInterior[index][1] = 0;
					testInterior[index+1][3] = 0;
				}
				return -1;
			}
		} else {
			int side = interior[location][(rotation+2)%4];
			testInterior[index][2] = side;
			testInterior[index+SIZE][0] = -side;
		}
		return mask - (1<<location);
	}

	static boolean equivalent(int x, int y) {
		if(x>0) {
			return ((x^y) & (~1))==0;
		}
		return (((-x)^(-y)) & (~1))==0;
	}

	static void removeTestPiece(int index) {
		if((index%SIZE)!=SIZE-1) {
			testInterior[index][1] = 0;
			testInterior[index+1][3] = 0;
		}
		if((index/SIZE)!=SIZE-1) {
			testInterior[index][2] = 0;
			testInterior[index+SIZE][0] = 0;
		}
	}

	static void fillTestMargin(int index) {
		for(int i=0;i<MARGIN_SIZE;i++) {
			int value = getMarginValue(interior,i);
			setMarginValue(testInterior,mappings[index][i],value);
		}
	}

	static int getMarginValue(int[][] interior, int index) {
		return interior[marginMap[index][0]][marginMap[index][1]];
	}

	static void setMarginValue(int[][] interior, int index, int value) {
		interior[marginMap[index][0]][marginMap[index][1]] = value;
	}

	static long setValue(long mask, int i, int j, int v) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		if(interior[i][j]!=0) {
			if(interior[i][j]==v)
				return mask;
			return -1;
		}
		int v1;
		int v2;
		int i1;
		int i2;
		int j1;
		int j2;
		if(v<0) {
			v1=-v;
			v2=v;
			i1=i+DELTA[j];
			i2=i;
			j1=ROTATE[j];
			j2=j;
		} else {
			v1=v;
			v2=-v;
			i1=i;
			i2=i+DELTA[j];
			j1=j;
			j2=ROTATE[j];
		}
		long bit = (1L<<0)<<(v1-2);
		if((mask & bit)==0) {
			if(lookup[v1-2]!=(i1<<2)+j1)
				return -1;
			throw new RuntimeException();
		}
		//System.out.println("setValue: "+i+" "+j+" "+v+" "+i1+" "+j1+" "+" "+i2+" "+j2);
		//System.out.println("Somewhere in setvalue: "+Long.toString(mask,16)+" "+Long.toString(bit,16)+" "+v1+" "+lookup[v1-2]);
		if(lookup[v1-2]!=-1)
			throw new RuntimeException();

		if(interior[i1][j1]!=0 || interior[i2][j2]!=0)
			throw new RuntimeException();
		lookup[v1-2] = (i1<<2)+j1;
		interior[i1][j1]=v1;
		interior[i2][j2]=v2;
		mask &= ~bit;

		// If either piece is already mapped, set the corresponding edge on the other puzzle.
		int piece = placement[i1];
		if(piece>=0) {
			mask = setDualValue(mask, piece>>2,(j1+piece)%4,v1);
			if(mask==-1)
				return mask;
		}
		piece = placement[i2];
		if(piece>=0) {
			mask = setDualValue(mask, piece>>2,(j2+piece)%4,v2);
			if(mask==-1)
				return mask;
		}
		// If an edge is already placed, make the connection.
		if((mask & ((1L<<24)<<(v1-2)))==0) {
			mask = connect(v1, mask);
			if(mask==-1)
				return mask;
		}
		if((mask & ((1L<<24)<<((v1^1)-2)))==0) {
			mask = connect(v2, mask);
			if(mask==-1)
				return mask;
		}
		return mask;
	}

	static long setDualValue(long mask, int i, int j, int v) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		if(dualInterior[i][j]!=0) {
			if(dualInterior[i][j]==v)
				return mask;
			return -1;
		}
		int v1;
		int v2;
		int i1;
		int i2;
		int j1;
		int j2;
		if(v<0) {
			v1=(-v)^1;
			v2=v;
			i1=i+DELTA[j];
			i2=i;
			j1=ROTATE[j];
			j2=j;
		} else {
			v1=v;
			v2=-(v^1);
			i1=i;
			i2=i+DELTA[j];
			j1=j;
			j2=ROTATE[j];
		}
		long bit = (1L<<24)<<(v1-2);
		if((mask & bit)==0) {
			if(dualLookup[v1-2]!=(i1<<2)+j1)
				return -1;
			throw new RuntimeException();
		}
		if(dualLookup[v1-2]!=-1)
			throw new RuntimeException();

		//System.out.println("setDualValue: "+i+" "+j+" "+v+" "+i1+" "+j1+" "+" "+i2+" "+j2);

		if(dualInterior[i1][j1]!=0 || dualInterior[i2][j2]!=0)
			return -1;

		dualLookup[v1-2] = (i1<<2)+j1;
		dualInterior[i1][j1]=v1;
		dualInterior[i2][j2]=v2;
		mask &= ~bit;

		// If either piece is already mapped, set the corresponding edge on the other puzzle.
		int piece = dualPlacement[i1];
		if(piece>=0) {
			mask = setValue(mask, piece>>2,(j1+piece)%4,v1);
			if(mask==-1)
				return mask;
		}
		piece = dualPlacement[i2];
		if(piece>=0) {
			mask = setValue(mask, piece>>2,(j2+piece)%4,v2);
			if(mask==-1)
				return mask;
		}
		// If an edge is already placed, make the connection.
		if((mask & (1L<<(v1-2)))==0) {
			mask = connect(v1, mask);
			if(mask==-1)
				return mask;
		}
		if((mask & (1L<<((v1^1)-2)))==0) {
			//System.out.println("@@@@@@ "+v1);
			mask = connect(v2, mask);
			if(mask==-1)
				return mask;
		}
		return mask;
	}

	static void checkConsistancy(long mask) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		int count=0;
		int dualCount=0;
		for(int i=0;i<SIZE*SIZE;i++) {
			if(placement[i]>=0)
				count++;
			if(dualPlacement[i]>=0)
				dualCount++;
			if((mask & ((1L<<48)<<i))!=0) {
				if(placement[i]>=0)
					throw new RuntimeException();
				continue;
			}
			if(placement[i]<0)
				throw new RuntimeException();
			int k=placement[i];
			int kk=dualPlacement[k>>2];
			if(((k+kk)%4)!=0)
				throw new RuntimeException();
			if((kk>>2) != i)
				throw new RuntimeException();
			// Actually, these can be inconsistent for just a sec before we catch it.
			//for(int j=0;j<3;j++) {
				//if(interior[kk][(kk+j)%4] != dualInterior[k][(k+j)%4])
					//throw new RuntimeException();
			//}
		}
		if(count!=dualCount)
			throw new RuntimeException();
		// They line up as desired.  They also need to be internally consistent.
	}

	static long connect(int value, long mask) {
		if((mask&2)!=0 && lookup[1]!=-1)
			throw new RuntimeException();
		checkConsistancy(mask);
		if(false) {
			printPuzzle(interior);
			printPuzzle(dualInterior);
			System.out.println("Connect: "+value+" "+Long.toString(mask,16));
		}
		int i,j,iD,jD;
		if(value>0) {
//System.out.println(lookup[value-2]+" "+dualLookup[value-2]);
			i=lookup[value-2]/4;
			j=lookup[value-2]%4;
			iD=dualLookup[value-2]/4;
			jD=dualLookup[value-2]%4;
		} else {
//System.out.println(lookup[-value-2]+" "+dualLookup[(-value-2)^1]);
			i=lookup[-value-2]/4;
			j=lookup[-value-2]%4;
			iD=dualLookup[(-value-2)^1]/4;
			jD=dualLookup[(-value-2)^1]%4;
			i = i+DELTA[j];
			j = ROTATE[j];
			iD = iD+DELTA[jD];
			jD = ROTATE[jD];
		}

		if(interior[i][j] != value)
			throw new RuntimeException();
		if(dualInterior[iD][jD] != value)
			throw new RuntimeException();

		if(placement[i]!=-1 || dualPlacement[iD]!=-1) {
			if(placement[i]==(iD<<2) + ((jD-j+4)%4))
				return mask;
			return -1;
		}
		placement[i]=(iD<<2) + ((jD-j+4)%4);
		dualPlacement[iD]=(i<<2) + ((j-jD+4)%4);

		mask &= ~(((1L<<48)<<i));

		for(int k=1;k<4;k++) {
			int v1=interior[i][(j+k)%4];
			int v2=dualInterior[iD][(jD+k)%4];
			if(v1!=v2) {
				if(v1==0) {
					mask = setValue(mask,i,(j+k)%4,v2);
					if(mask==-1)
						return mask;
				} else if(v2==0) {
					mask = setDualValue(mask,iD,(jD+k)%4,v1);
					if(mask==-1)
						return mask;
				} else {
					return -1;
				}
			}
		}
		return mask;
	}

	static int[][] generateMarginMap() {
		int[][] map = new int[MARGIN_SIZE][2];
		for(int i=0;i<SIZE;i++) {
			map[i][0]=i;
			map[i][1]=0;

			map[i+SIZE][0]=SIZE*i+SIZE-1;
			map[i+SIZE][1]=1;

			map[i+2*SIZE][0]=SIZE*SIZE-i-1;
			map[i+2*SIZE][1]=2;

			map[i+3*SIZE][0]=SIZE*(SIZE-i-1);
			map[i+3*SIZE][1]=3;
		}
		return map;
	}

	static char[][][] makeGrid() {
		char[][][] grid = new char[SIZE+2][SIZE+2][4];
		initGrid(grid);
		return grid;
	}

	static void initGrid(char[][][] grid) {
		for(int i=0;i<SIZE+2;i++) {
			for(int j=0;j<SIZE+2;j++) {
				if(i==0)
					grid[i][j][3]='|';
				else
					grid[i][j][3]=' ';
				if(i==SIZE+1)
					grid[i][j][1]='|';
				else
					grid[i][j][1]=' ';
				if(j==0)
					grid[i][j][0]='-';
				else
					grid[i][j][0]=' ';
				if(j==SIZE+1)
					grid[i][j][2]='-';
				else
					grid[i][j][2]=' ';
			}
		}
	}

	static void fillGridBorder(char[][][] grid, int skew) {
		int link=0;
		initGrid(grid);
		for(int i=0;i<BORDER_SIZE;i++) {
			if(i<SIZE+1) {
				if(i==0) {
					grid[i][0][2]=(char)('a'+link/2);
				} else {
					grid[i][0][3]=(char)('a'+link/2);
				}
				grid[i][0][1]=(char)('A'+borders[link]/2);
			} else if(i<2*SIZE+2) {
				if(i==SIZE+1) {
					grid[SIZE+1][i-SIZE-1][3]=(char)('a'+link/2);
				} else {
					grid[SIZE+1][i-SIZE-1][0]=(char)('a'+link/2);
				}
				grid[SIZE+1][i-SIZE-1][2]=(char)('A'+borders[link]/2);
			} else if(i<3*SIZE+3) {
				if(i==2*SIZE+2) {
					grid[3*SIZE+3-i][SIZE+1][0]=(char)('a'+link/2);
				} else {
					grid[3*SIZE+3-i][SIZE+1][1]=(char)('a'+link/2);
				}
				grid[3*SIZE+3-i][SIZE+1][3]=(char)('A'+borders[link]/2);
			} else {
				if(i==3*SIZE+3) {
					grid[0][4*SIZE+4-i][1]=(char)('a'+link/2);
				} else {
					grid[0][4*SIZE+4-i][2]=(char)('a'+link/2);
				}
				grid[0][4*SIZE+4-i][0]=(char)('A'+borders[link]/2);
			}

			link=borders[link]^((skew>>(borders[link]/2))&1);
		}
	}

	static void fillGridInterior(char[][][] grid, int[][] interior) {
		for(int i=0;i<SIZE;i++)
			for(int j=0;j<SIZE;j++)
				for(int k=0;k<4;k++)
					if(interior[SIZE*j+i][k]<0)
						grid[i+1][j+1][k] = (char)('A'+1+SIZE*2-interior[SIZE*j+i][k]/2);
					else
						grid[i+1][j+1][k] = (char)('a'+1+SIZE*2+interior[SIZE*j+i][k]/2);
	}

	static void printPuzzle(int[][] puzzle) {
		System.out.println();
		for(int i=0;i<puzzle.length;i++) {
			System.out.println(puzzle[i][0]+" "+puzzle[i][1]+" "+puzzle[i][2]+" "+puzzle[i][3]+" ");
		}
		for(int j=0;j<SIZE;j++) {
			for(int i=0;i<SIZE;i++) {
				System.out.print("*-"+makeSign(puzzle[SIZE*j+i][0])+makeChar(puzzle[SIZE*j+i][0])+"-*");
			}
			System.out.println();

			for(int i=0;i<SIZE;i++) {
				System.out.print("|    |");
			}
			System.out.println();

			for(int i=0;i<SIZE;i++) {
				System.out.print(makeSign(puzzle[SIZE*j+i][3])+"    "+makeSign(puzzle[SIZE*j+i][1]));
			}
			System.out.println();

			for(int i=0;i<SIZE;i++) {
				System.out.print(makeChar(puzzle[SIZE*j+i][3])+"    "+makeChar(puzzle[SIZE*j+i][1]));
			}
			System.out.println();

			for(int i=0;i<SIZE;i++) {
				System.out.print("|    |");
			}
			System.out.println();

			for(int i=0;i<SIZE;i++) {
				System.out.print("*-"+makeSign(puzzle[SIZE*j+i][2])+makeChar(puzzle[SIZE*j+i][2])+"-*");
			}
			System.out.println();

		}
		
	}

	static char makeSign(int value) {
		return Integer.toString(200+value).charAt(1);
	}

	static char makeChar(int value) {
		return Integer.toString(200+value).charAt(2);
	}

	static void printArray(char[][][] grid) {
		System.out.println("[");
		for(int i=0;i<SIZE+2;i++) {
			if(i!=0)
				System.out.println(",");
			System.out.print("[  ");
			for(int j=0;j<SIZE+2;j++) {
				if(j!=0)
					System.out.print(",  ");
				System.out.print("[");
					for(int k=0;k<4;k++) {
						if(k!=0)
							System.out.print(",");
						char g = grid[i][j][k];
						if(g=='|' || g=='-')
							System.out.print(0);
						if(g>='a' && g<='z')
							System.out.print((int)(g-'a'+1));
						else if(g>='A' && g<='Z')
							System.out.print(-(int)(g-'A'+1));
					}
				System.out.print("]");
			}
			System.out.print("  ]");
		}
		System.out.println();
		System.out.println("]");
		System.out.println();
	}

	static void printGrid(char[][][] grid) {
		System.out.println();
		for(int j=0;j<SIZE+2;j++) {
			for(int i=0;i<SIZE+2;i++) {
				System.out.print("*-"+grid[i][j][0]+grid[i][j][0]+"-*");
			}
			System.out.println();

			for(int i=0;i<SIZE+2;i++) {
				System.out.print("|    |");
			}
			System.out.println();

			for(int i=0;i<SIZE+2;i++) {
				System.out.print(grid[i][j][3]+"    "+grid[i][j][1]);
			}
			System.out.println();

			for(int i=0;i<SIZE+2;i++) {
				System.out.print(grid[i][j][3]+"    "+grid[i][j][1]);
			}
			System.out.println();

			for(int i=0;i<SIZE+2;i++) {
				System.out.print("|    |");
			}
			System.out.println();

			for(int i=0;i<SIZE+2;i++) {
				System.out.print("*-"+grid[i][j][2]+grid[i][j][2]+"-*");
			}
			System.out.println();
		}
		System.out.println();

	}

}

